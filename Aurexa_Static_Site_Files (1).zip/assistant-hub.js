(()=>{'use strict';
const urls={1:'https://shashi-hindi-class1-aurexa.alightgrove2.chatgpt.site',2:'https://shashi-hindi-grade2-aurexa.alightgrove2.chatgpt.site',3:'https://shashi-hindi-grade3-aurexa.alightgrove2.chatgpt.site',4:'https://shashi-hindi-grade4-aurexa.alightgrove2.chatgpt.site',5:'https://shashi-hindi-grade5-aurexa.alightgrove2.chatgpt.site'};
const entryMatch=location.hash.match(/^#grade-([1-5])$/);
const bookGrade=entryMatch?+entryMatch[1]:null;
if(bookGrade){
 document.querySelector('.assistant-hub .eyebrow').textContent=`SHASHI HINDI VYAKARAN · GRADE ${bookGrade}`;
 document.title=`Aurexa AI Assistant | Grade ${bookGrade}`;
 document.querySelector('.hub-grades').hidden=true;
 document.getElementById('navigation').hidden=true;
 document.getElementById('menu-toggle').hidden=true;
 document.querySelector('.hub-intro').nextElementSibling.textContent=`Welcome to Grade ${bookGrade}. Choose Teacher or Student below.`;
}
const frame=document.getElementById('assistant-frame'),status=document.getElementById('assistant-status'),open=document.getElementById('assistant-open'),qr=document.getElementById('assistant-qr'),download=document.getElementById('assistant-qr-download');let current=1;
function choose(){const match=location.hash.match(/^#grade-([1-5])$/),grade=bookGrade||(match?+match[1]:1);if(grade!==current){current=grade;frame.src=urls[grade];status.textContent=`Loading Grade ${grade} assistant…`;}frame.title=`Aurexa AI Assistant Grade ${grade}`;open.href=urls[grade];open.textContent=`Open Grade ${grade} in a new tab ↗`;document.getElementById('assistant-grade-heading').textContent=`Grade ${grade} · Hindi`;qr.src=`assets/assistant-grade${grade}-qr.png`;qr.alt=`QR code for Aurexa AI Assistant Grade ${grade}`;download.href=qr.getAttribute('src');download.textContent=`Download Grade ${grade} QR code`;document.querySelectorAll('[data-assistant-grade]').forEach(a=>{if(+a.dataset.assistantGrade===grade)a.setAttribute('aria-current','true');else a.removeAttribute('aria-current')});}
frame.addEventListener('load',()=>{status.textContent=`Grade ${current} selected. If the assistant is not visible, open it in a new tab.`});window.addEventListener('hashchange',choose);choose();
})();
