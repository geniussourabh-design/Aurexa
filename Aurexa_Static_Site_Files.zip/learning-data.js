export const SERIES = {
  gk: { title: 'GK Spark', subtitle: 'General knowledge with reasoning' },
  hindi: { title: 'Shashi Hindi Vyakaran evam Rachna', subtitle: 'Hindi grammar & composition' }
};
export const GRADE_NOTES = [
  'Starting with the joy of discovery', 'Noticing more of the world around us',
  'Making connections, one idea at a time', 'Growing curiosity and confidence',
  'Practising with purpose', 'Taking the next step in independent thinking',
  'Exploring ideas in greater depth', 'Thinking critically. Expressing clearly.'
];
export const DESCRIPTIONS = {
  gk: [
    'Simple facts, familiar places and playful patterns for young learners.',
    'Everyday discoveries with a little more observation and reasoning.',
    'Connect familiar facts with new ideas about India and the wider world.',
    'Explore, compare and practise making thoughtful connections.',
    'A growing world of knowledge, with space to apply and explain.',
    'Broader discoveries, milestones and practical reasoning challenges.',
    'Look more closely at our world and develop independent thinking.',
    'Explore contemporary ideas, wider perspectives and deeper reasoning.'
  ],
  hindi: [
    'Start with letters and everyday words, one small step at a time.',
    'Explore words, simple sentences and the joy of using Hindi.',
    'Notice how words work and express ideas in clear sentences.',
    'Build language awareness through grammar and guided expression.',
    'Practise making sentences more meaningful and expressive.',
    'Connect grammar practice with clearer written expression.',
    'Explore language choices and organise ideas with growing confidence.',
    'Strengthen grammar, composition and thoughtful self-expression.'
  ]
};
const gk = [
  {title:'Shapes all around us',info:'A triangle has three sides. A square has four sides. A circle is round.',question:'Which shape has three sides?',answer:'A triangle has three sides.',think:'Where can you spot a triangle around you?',example:'For example, in a triangular flag or a slice of pizza.'},
  {title:'A moment to notice',info:'We use our eyes to see, our ears to hear and our nose to smell.',question:'Which sense organ helps you hear a bell?',answer:'Your ears help you hear the bell.',think:'How do your senses help you on the way to school?',example:'For example, eyes help you notice the road and ears help you hear traffic.'},
  {title:'Feathers of India',info:'The Indian peacock is India’s national bird. The tiger is India’s national animal.',question:'Complete the sentence: India’s national bird is the _____.',answer:'Indian peacock.',think:'Why should we take care of birds and animals?',example:'For example, they are living things and are part of the natural world.'},
  {title:'Our solar neighbourhood',info:'Earth is one of the eight planets in our solar system. The planets travel around the Sun.',question:'True or false: The planets in our solar system travel around Earth.',answer:'False. The planets travel around the Sun.',think:'What would you like to learn about another planet?',example:'Your own question is welcome—for example, what its surface looks like.'},
  {title:'Spot the pattern',info:'Look at this number pattern: 3, 6, 9, 12. Each number is three more than the one before it.',question:'What number comes after 12?',answer:'15. Add 3 to 12.',think:'How would the pattern change if you started with 2?',example:'It would become 2, 5, 8, 11, 14… when you keep adding 3.'},
  {title:'Reason it out',info:'A school club has 12 members. Seven members enjoy chess, six enjoy quizzes, and three enjoy both.',question:'How many members enjoy chess or quizzes, or both?',answer:'10 members. Add 7 and 6, then subtract the 3 counted twice.',think:'Why do we subtract the members who enjoy both?',example:'They appear in both groups, so we need to count them just once.'},
  {title:'From field to food',info:'Wheat and rice are both grown in Haryana. Farmers use water, soil and suitable growing conditions to produce crops.',question:'Name the two crops grown in Haryana mentioned above.',answer:'Wheat and rice.',think:'Why might farmers need to use water thoughtfully?',example:'For example, water is needed by crops and also by people, animals and other plants.'},
  {title:'A thoughtful approach to AI',info:'An AI tool can help find patterns or draft an answer. Its output can still contain mistakes, so people need to check the result.',question:'True or false: An answer must be correct just because an AI tool wrote it.',answer:'False. People should check an AI tool’s output.',think:'How could you check a surprising fact before sharing it?',example:'For example, compare it with a reliable reference and check that the source supports the claim.'}
];
const hindi = [
  {title:'शब्दों की छोटी दुनिया',info:'कमल, कलम और किताब तीन शब्द हैं। हर शब्द में अलग-अलग अक्षर होते हैं।',question:'इनमें से किस शब्द में “त” अक्षर है: कमल, कलम, किताब?',answer:'किताब।',think:'“क” से शुरू होने वाला एक और शब्द बताइए।',example:'उदाहरण: कबूतर। दूसरे सही शब्द भी स्वीकार्य हैं।'},
  {title:'वाक्य में शब्द',info:'“रीमा किताब पढ़ती है।” इस वाक्य में रीमा एक व्यक्ति का नाम है और किताब एक वस्तु का नाम है।',question:'वाक्य में वस्तु का नाम कौन-सा शब्द है?',answer:'किताब।',think:'अपने पास रखी किसी वस्तु का नाम बताइए।',example:'उदाहरण: पेंसिल, मेज़ या बैग।'},
  {title:'संज्ञा को पहचानें',info:'किसी व्यक्ति, स्थान, वस्तु या भाव के नाम को संज्ञा कहते हैं। “रोहन दिल्ली में रहता है।” में रोहन और दिल्ली संज्ञा हैं।',question:'दिए गए वाक्य में स्थान का नाम क्या है?',answer:'दिल्ली।',think:'अपने शहर के नाम से एक वाक्य बनाइए।',example:'उदाहरण: मैं रेवाड़ी में रहता हूँ। अपना शहर लिखना भी सही है।'},
  {title:'विशेषण की पहचान',info:'विशेषण किसी संज्ञा की विशेषता बताता है। “लाल फूल” में लाल शब्द फूल का रंग बताता है।',question:'“लाल फूल” में विशेषण कौन-सा शब्द है?',answer:'लाल।',think:'अपने पसंदीदा फल के लिए एक विशेषण बताइए।',example:'उदाहरण: मीठा आम।'},
  {title:'विलोम शब्द',info:'विपरीत अर्थ वाले शब्दों को विलोम शब्द कहते हैं। “दिन” का विलोम “रात” और “ऊँचा” का विलोम “नीचा” है।',question:'सूचना के आधार पर “ऊँचा” का विलोम लिखिए।',answer:'नीचा।',think:'“दिन” और “रात” को एक वाक्य में प्रयोग कीजिए।',example:'उदाहरण: दिन में उजाला होता है और रात में अँधेरा होता है।'},
  {title:'कारण और परिणाम',info:'“क्योंकि” कारण बताने के लिए प्रयोग होता है। उदाहरण: मैं छाता लाया क्योंकि बारिश हो रही थी।',question:'दिए गए वाक्य में छाता लाने का कारण क्या है?',answer:'बारिश हो रही थी।',think:'“क्योंकि” का प्रयोग करके अपना एक वाक्य बनाइए।',example:'उदाहरण: मैंने पानी पिया क्योंकि मुझे प्यास लगी थी।'},
  {title:'शब्द से अभिव्यक्ति',info:'“लेकिन” दो विचारों के बीच विरोध या अंतर दिखा सकता है। उदाहरण: रास्ता लंबा था, लेकिन सफ़र अच्छा लगा।',question:'दिए गए वाक्य में दो विचारों को जोड़ने वाला शब्द कौन-सा है?',answer:'लेकिन।',think:'“लेकिन” का प्रयोग करके एक नया वाक्य बनाइए।',example:'उदाहरण: प्रश्न कठिन था, लेकिन मैंने प्रयास किया।'},
  {title:'अनुच्छेद की एकता',info:'एक अच्छे अनुच्छेद के वाक्य मुख्य विषय से जुड़े रहते हैं। “वृक्षों का महत्त्व” विषय में छाया, फल और स्वच्छ हवा जैसे विचार शामिल हो सकते हैं।',question:'“वृक्षों का महत्त्व” विषय से जुड़े कोई दो विचार लिखिए।',answer:'उदाहरण: छाया और फल। “स्वच्छ हवा” भी सही है।',think:'इसी विषय पर अपना एक आरंभिक वाक्य लिखिए।',example:'उदाहरण: वृक्ष हमारे जीवन में बहुत उपयोगी हैं।'}
];
export function validGrade(value) { const n=Number(value); return Number.isInteger(n)&&n>=1&&n<=8?n:1; }
export function getActivity(subject,grade) { return (subject==='hindi'?hindi:gk)[validGrade(grade)-1]; }
export function parseSelection(value) {
  if(!Array.isArray(value))return [];
  const unique=new Map();
  for(const item of value){if(item&&Object.hasOwn(SERIES,item.series)&&Number.isInteger(item.grade)&&item.grade>=1&&item.grade<=8){unique.set(`${item.series}-${item.grade}`,{series:item.series,grade:item.grade});}}
  return [...unique.values()].sort((a,b)=>a.series.localeCompare(b.series)||a.grade-b.grade);
}
export function buildBrief(fields,selection,services,date=new Date()) {
  const books=parseSelection(selection);
  const clean=value=>String(value??'').trim().replace(/\r/g,'');
  const school=clean(fields.school),city=clean(fields.city);
  if(!school||!city)throw new Error('Please add the school name and city.');
  if(!books.length&&!services.length)throw new Error('Add a book or choose a service to include in your brief.');
  const dateString=new Intl.DateTimeFormat('en-IN',{year:'numeric',month:'long',day:'numeric',timeZone:'Asia/Kolkata'}).format(date);
  const lines=['AUREXA LEARNING HOUSE','School evaluation & enquiry brief',`Prepared: ${dateString}`,'',`School / organisation: ${school}`,`City / district: ${city}`];
  if(clean(fields.name))lines.push(`School representative: ${clean(fields.name)}`);
  if(clean(fields.role))lines.push(`Role: ${clean(fields.role)}`);
  if(books.length){lines.push('','BOOKS TO EXPLORE');for(const book of books)lines.push(`- ${SERIES[book.series].title} — Class ${book.grade}`);}
  if(services.length){lines.push('','SERVICES / SUPPORT');for(const service of [...new Set(services)])lines.push(`- ${clean(service)}`);}
  if(clean(fields.notes))lines.push('','SCHOOL REQUIREMENTS',clean(fields.notes));
  lines.push('','This brief was prepared on your device. It has not been submitted or sent.','Share it with your Aurexa representative to discuss samples, availability, specifications and pricing.');
  return lines.join('\n');
}
