import {SERIES,GRADE_NOTES,DESCRIPTIONS,validGrade,getActivity,parseSelection,buildBrief} from './learning-data.js';
import {EMAIL_ADDRESS,buildEmailOptions} from './email-options.js';
const $=selector=>document.querySelector(selector);
const $$=selector=>[...document.querySelectorAll(selector)];
const escapeHTML=text=>String(text).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const storageKey='aurexa-school-books-v1';
const legacyPages={'#books':'books.html#books','#learning':'books.html#learning','#classrooms':'interactive-flat-panels.html#classrooms','#about':'about.html#about','#contact':'contact.html#contact','#enquiry':'contact.html#enquiry'};
if(['','index.html'].includes(window.location.pathname.split('/').pop())&&legacyPages[window.location.hash])window.location.replace(legacyPages[window.location.hash]);
let grade=1,subject='gk',dialogSubject='gk',briefText='',selection=[];
try{selection=parseSelection(JSON.parse(localStorage.getItem(storageKey)||'[]'));}catch{selection=[];}
let toastTimer;
function toast(message){const el=$('#toast');el.textContent=message;el.hidden=false;clearTimeout(toastTimer);toastTimer=setTimeout(()=>{el.hidden=true;},3200);}
function saveSelection(){try{localStorage.setItem(storageKey,JSON.stringify(selection));}catch{}renderSelection();}
function hasBook(series){return selection.some(item=>item.series===series&&item.grade===grade);}
function addBook(series){if(!Object.hasOwn(SERIES,series))return;if(hasBook(series)){toast(`Class ${grade} is already in your school brief.`);return;}selection=parseSelection([...selection,{series,grade}]);saveSelection();toast(`${series==='gk'?'GK Spark':'Shashi Hindi'} · Class ${grade} added to your brief.`);}
function renderSelection(){
  const list=$('#shortlist-items');list?.replaceChildren();
  if(list&&!selection.length){const p=document.createElement('p');p.className='empty-shortlist';p.append('Your next chapter is waiting.');const span=document.createElement('span');span.textContent='Add books from the bookshelf, or choose a service below.';p.append(span);list.append(p);}
  if(list)for(const item of selection){const row=document.createElement('div');row.className='shortlist-row';const copy=document.createElement('div');copy.textContent=SERIES[item.series].title;const small=document.createElement('small');small.textContent=`Class ${item.grade}`;copy.append(small);const remove=document.createElement('button');remove.type='button';remove.className='remove-item';remove.textContent='×';remove.setAttribute('aria-label',`Remove ${SERIES[item.series].title} Class ${item.grade}`);remove.addEventListener('click',()=>{selection=selection.filter(v=>v.series!==item.series||v.grade!==item.grade);saveSelection();});row.append(copy,remove);list.append(row);}
  if($('#shortlist-count'))$('#shortlist-count').textContent=selection.length;$('#nav-count').textContent=selection.length;$('#nav-count').hidden=!selection.length;
  $$('[data-add]').forEach(button=>{const added=hasBook(button.dataset.add);button.classList.toggle('added',added);button.replaceChildren(document.createTextNode(added?'Added to brief':'Add to school brief'));const span=document.createElement('span');span.setAttribute('aria-hidden','true');span.textContent=added?'✓':'+';button.append(span);});
}
function activityHTML(series){const a=getActivity(series,grade),lang=series==='hindi'?' lang="hi"':'';return `<div${lang}><h3 class="activity-title">${escapeHTML(a.title)}</h3><p class="activity-info">${escapeHTML(a.info)}</p><p class="activity-question">${escapeHTML(a.question)}</p><p class="activity-think"><b>THINK SMART</b>${escapeHTML(a.think)}</p></div>`;}
function answer(series){const a=getActivity(series,grade);return `${a.answer}\n\nThink Smart — one possible answer:\n${a.example}`;}
function renderPractice(){if(!$('#practice-content'))return;$('#practice-content').innerHTML=activityHTML(subject);$('#practice-grade').textContent=`CLASS ${grade}`;$('#practice-answer').hidden=true;$('#practice-answer').textContent=answer(subject);$('#practice-answer').lang=subject==='hindi'?'hi':'en';$('#answer-toggle').setAttribute('aria-expanded','false');$('#answer-toggle').innerHTML='Reveal the answer <span aria-hidden="true">→</span>';$$('[data-practice]').forEach(b=>{const active=b.dataset.practice===subject;b.classList.toggle('active',active);b.setAttribute('aria-pressed',String(active));});}
function selectGrade(value){grade=validGrade(value);$$('[data-grade]').forEach(b=>{const active=Number(b.dataset.grade)===grade;b.classList.toggle('active',active);b.setAttribute('aria-pressed',String(active));});$$('.grade-label').forEach(label=>label.textContent=`Class ${grade}`);$('#class-note').textContent=GRADE_NOTES[grade-1];$('#gk-description').textContent=DESCRIPTIONS.gk[grade-1];$('#hindi-description').textContent=DESCRIPTIONS.hindi[grade-1];const image=$('#gk-cover img');const cover=$('#gk-cover');if(grade===8){image.src='assets/gk-eight.png';image.alt='GK Spark Class 8 cover design preview';cover.classList.remove('spread-front');image.style.cssText='width:100%;height:auto;position:static;max-width:100%;';$('#gk-caption').textContent='Class 8 cover design preview';}else{image.src='assets/gk-cover-spread.png';image.alt='GK Spark Class 1 cover design preview';cover.classList.add('spread-front');image.removeAttribute('style');$('#gk-caption').textContent=grade===1?'Class 1 cover design preview':'Series artwork · Class 1 cover preview';}renderPractice();renderSelection();}
$('#menu-toggle').addEventListener('click',()=>{const button=$('#menu-toggle'),open=button.getAttribute('aria-expanded')!=='true';button.setAttribute('aria-expanded',String(open));button.setAttribute('aria-label',open?'Close navigation':'Open navigation');$('#navigation').classList.toggle('open',open);});
$$('#navigation a').forEach(a=>a.addEventListener('click',()=>{$('#navigation').classList.remove('open');$('#menu-toggle').setAttribute('aria-expanded','false');$('#menu-toggle').setAttribute('aria-label','Open navigation');}));
document.addEventListener('keydown',event=>{if(event.key==='Escape'){$('#navigation').classList.remove('open');$('#menu-toggle').setAttribute('aria-expanded','false');$('#menu-toggle').setAttribute('aria-label','Open navigation');}});
$$('[data-grade]').forEach(button=>button.addEventListener('click',()=>selectGrade(button.dataset.grade)));
$$('[data-add]').forEach(button=>button.addEventListener('click',()=>addBook(button.dataset.add)));
$$('[data-practice]').forEach(button=>button.addEventListener('click',()=>{subject=button.dataset.practice;renderPractice();}));
$('#answer-toggle')?.addEventListener('click',()=>{const open=$('#practice-answer').hidden;$('#practice-answer').hidden=!open;$('#answer-toggle').setAttribute('aria-expanded',String(open));$('#answer-toggle').innerHTML=(open?'Hide the answer':'Reveal the answer')+' <span aria-hidden="true">→</span>';});
const dialog=$('#activity-dialog');
$$('[data-preview]').forEach(button=>button.addEventListener('click',()=>{dialogSubject=button.dataset.preview;$('#activity-dialog-title').textContent=`${dialogSubject==='gk'?'GK Spark':'Shashi Hindi'} · Class ${grade}`;$('#dialog-activity').innerHTML=activityHTML(dialogSubject);$('#dialog-answer-text').hidden=true;$('#dialog-answer-text').textContent=answer(dialogSubject);$('#dialog-answer-text').lang=dialogSubject==='hindi'?'hi':'en';$('#dialog-answer').textContent='Reveal the answer';dialog.showModal();}));
$('#close-dialog').addEventListener('click',()=>dialog.close());
dialog.addEventListener('click',event=>{if(event.target===dialog){const box=dialog.getBoundingClientRect();if(event.clientX<box.left||event.clientX>box.right||event.clientY<box.top||event.clientY>box.bottom)dialog.close();}});
$('#dialog-answer').addEventListener('click',()=>{const open=$('#dialog-answer-text').hidden;$('#dialog-answer-text').hidden=!open;$('#dialog-answer').textContent=open?'Hide the answer':'Reveal the answer';});
$('#dialog-add').addEventListener('click',()=>{addBook(dialogSubject);dialog.close();});
$('#add-ifp')?.addEventListener('click',()=>{window.location.href='contact.html?service=ifp#enquiry';});
if($('#ifp-service')&&new URLSearchParams(window.location.search).get('service')==='ifp')$('#ifp-service').checked=true;
$('#enquiry-form')?.addEventListener('submit',event=>{event.preventDefault();const form=event.currentTarget,status=$('#form-status');const fields=Object.fromEntries(new FormData(form));const services=$$('.brief-services input:checked').map(input=>input.value);try{briefText=buildBrief(fields,selection,services);status.hidden=true;$('#brief-text').textContent=briefText;$('#whatsapp-brief').href='https://wa.me/919306008031?text='+encodeURIComponent(briefText);$('#email-brief').href='mailto:info@aurexalearning.co.in?subject='+encodeURIComponent('School enquiry — '+fields.school)+'&body='+encodeURIComponent(briefText);$('#prepared-brief').hidden=false;$('#prepared-brief').scrollIntoView({behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth',block:'center'});toast('Your school brief is ready to download.');}catch(error){status.textContent=error.message;status.hidden=false;}});
$('#download-brief')?.addEventListener('click',()=>{if(!briefText)return;const blob=new Blob([briefText],{type:'text/plain;charset=utf-8'});const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='Aurexa_School_Enquiry_Brief.txt';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);toast('Your brief has been downloaded. It has not been sent.');});
$('#copy-brief')?.addEventListener('click',async()=>{try{await navigator.clipboard.writeText(briefText);toast('School brief copied.');}catch{toast('Copy is unavailable here. Please download the brief.');}});
$('#print-brief')?.addEventListener('click',()=>{if(briefText)window.print();});
const emailDialog=$('#email-dialog'),emailAddress=$('#email-address'),emailStatus=$('#email-status');
$$('[data-email-link]').forEach(link=>link.addEventListener('click',event=>{
  if(typeof emailDialog.showModal!=='function')return;
  const options=buildEmailOptions(link.getAttribute('href'));
  event.preventDefault();
  $('#email-app').href=options.mailto;
  $('#email-gmail').href=options.gmail;
  emailAddress.value=options.address;
  emailStatus.textContent='';
  emailDialog.showModal();
  $('#email-app').focus();
}));
$('#close-email-dialog').addEventListener('click',()=>emailDialog.close());
emailDialog.addEventListener('click',event=>{if(event.target===emailDialog){const box=emailDialog.getBoundingClientRect();if(event.clientX<box.left||event.clientX>box.right||event.clientY<box.top||event.clientY>box.bottom)emailDialog.close();}});
$('#copy-email-address').addEventListener('click',async()=>{
  try{await navigator.clipboard.writeText(EMAIL_ADDRESS);emailStatus.textContent='Email address copied.';}
  catch{emailAddress.focus();emailAddress.select();emailStatus.textContent='Select the address above and copy it into your email.';}
});
$('#year').textContent=new Date().getFullYear();
renderSelection();
if($('#class-buttons'))selectGrade(grade);
