export const EMAIL_ADDRESS='info@aurexalearning.co.in';

export function buildEmailOptions(mailto){
  const recipient=mailto.slice(7).split('?')[0];
  if(!mailto.startsWith('mailto:')||recipient!==EMAIL_ADDRESS)throw new Error('Invalid email destination.');
  return {
    address:EMAIL_ADDRESS,
    mailto,
    gmail:'https://mail.google.com/mail/?extsrc=mailto&url='+encodeURIComponent(mailto)
  };
}
