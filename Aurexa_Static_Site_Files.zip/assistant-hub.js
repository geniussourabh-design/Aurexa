(() => {
  function openScannedGrade() {
    const grade = location.hash.match(/^#grade-([1-5])$/)?.[1];
    if (grade) location.replace(`assistants/grade-${grade}/index.html`);
  }
  window.addEventListener('hashchange', openScannedGrade);
  openScannedGrade();
})();
