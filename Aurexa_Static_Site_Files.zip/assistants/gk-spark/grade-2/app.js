const $ = id => document.getElementById(id);
const imageChapters=new Set();
const labels = {paper:'Question paper', worksheet:'Worksheet', key:'Answer key', lesson:'Lesson plan', dictionary:'Audio-visual dictionary'};
const formats = {fill:'Fill in the blanks', mcq:'Multiple choice', tf:'True or false', match:'Matching', think:'Think Smart', clock:'Flag diagrams'};
const escapeHTML = v => String(v).replace(/[&<>"']/g, x => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[x]));
const shuffled = items => {
  const copy=[...items];
  for(let i=copy.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[copy[i],copy[j]]=[copy[j],copy[i]];}
  return copy;
};
const selected = () => chapters.filter(c=>$('chapter-'+c.id).checked);
let mode='paper', last=null;
try { last=JSON.parse(sessionStorage.getItem('gk-spark-grade-2-last')); } catch {}
$('chapters').innerHTML=chapters.map(c=>`<label><input type="checkbox" id="chapter-${c.id}" checked>${c.id}. ${escapeHTML(c.title)}</label>`).join('');
$('dict-chapter').insertAdjacentHTML('beforeend',chapters.map(c=>`<option value="${c.id}">${c.id}. ${escapeHTML(c.title)}</option>`).join(''));
function setScope(){
  const count=selected().length;
  $('scope').textContent=count===chapters.length?`All ${chapters.length} chapters`:`${count} selected chapter${count===1?'':'s'}`;
}
$('chapters').addEventListener('change',setScope);
for(const key of ['all','none']) $(key).onclick=()=>{
  chapters.forEach(c=>$('chapter-'+c.id).checked=key==='all');
  setScope();
};
function setMode(next){
  mode=next;
  document.querySelectorAll('[data-mode]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.mode===next)));
  $('controls').hidden=next==='dictionary';
  $('dictionary').hidden=next!=='dictionary';
  $('form').hidden=next==='key';
  $('key-controls').hidden=next!=='key';
  $('lesson-field').hidden=next!=='lesson';
  $('settings').hidden=next==='lesson';
  $('size-field').firstChild.nodeValue=next==='worksheet'?'Number of questions':'Total marks';
  $('tool-title').textContent=labels[next];
  $('generate').textContent='Generate '+labels[next].toLowerCase();
  $('status').textContent='';
  $('output').hidden=true;
  if(next==='key'){
    $('open-key').disabled=!last;
    $('key-msg').textContent=last?'Show the key for the most recently generated resource.':'Generate a question paper or worksheet first.';
    if(last) showKey(false);
  }
  if(next==='dictionary') showWords();
}
document.querySelectorAll('[data-mode]').forEach(b=>b.onclick=()=>setMode(b.dataset.mode));
const think = {"4": ["What could you do to look after a park you visit?", "Use a bin and leave plants and wildlife undisturbed."], "11": ["How can we help protect old monuments?", "Do not scratch the walls. Keep the grounds clean and follow the rules."], "18": ["What can you do if a park is untidy?", "Tell a trusted adult and put litter in a bin when it is safe to do so."]};
function pools(scope){
  const facts=shuffled(scope.flatMap(c=>c.facts.map(([cue,answer])=>({cue,answer,c}))));
  const bank={fill:[],mcq:[],tf:[],match:[],think:[],clock:[]};
  const choiceGroups=[
    ['Asia','Africa','Europe','Australia'],['New Delhi','Mumbai','Bhopal','Jaipur','Chandigarh','Kavaratti','France','Egypt','Gujarat','Assam','Rajasthan','Faridabad','northern India','Morni Hills','Rakhigarhi','Konark'],
    ['Kalpana Chawla','Mahatma Gandhi','Sarojini Naidu','Lala Lajpat Rai','Rabindranath Tagore','Satyajit Ray','C. V. Raman','Vikram Sarabhai','Major Dhyan Chand','P. T. Usha','Netaji'],
    ['tabla','bansuri','sitar'],['boxing','hockey','chess'],['1947','1857','1906','1921'],['Diwali','Baisakhi','Pongal','Holi'],['source','course','mouth'],['plateau','mountain range','plain','coast'],['hour','week','year','minute'],['Tadasana','Vrikshasana','meditation'],['ballet','Bharatanatyam','Flamenco']
  ];
  for(const f of facts){
    const ofChapter=f.c.facts.map(p=>p[1]);
    const family=choiceGroups.find(group=>group.includes(f.answer));
    const options=shuffled([...new Set([...(family??ofChapter),...ofChapter])].filter(a=>a!==f.answer));
    bank.fill.push({prompt:f.cue+' ________',answer:f.answer});
    const choices=shuffled([f.answer,...options.slice(0,3)]);
    bank.mcq.push({prompt:f.cue+' …',choices,answer:`${String.fromCharCode(65+choices.indexOf(f.answer))}. ${f.answer}`});
    const wrong=options[0];
    const truth=Math.random()>.5;
    bank.tf.push({prompt:`${f.cue}: ${truth?f.answer:wrong}.`,answer:truth?'True':`False. Correct answer: ${f.answer}.`});
  }
  for(const ch of shuffled(scope)){
    const pairs=shuffled(ch.facts).slice(0,2);
    const right=shuffled(pairs.map(p=>p[1]));
    if(right[0]!==right[1]) bank.match.push({prompt:'Match the two clues to the correct answers.',pairs,right,answer:pairs.map(([_,a],i)=>`${i+1}–${String.fromCharCode(65+right.indexOf(a))} (${a})`).join(', '),cost:2});
    const sample=think[ch.id]??[`Explain “${ch.word}” in your own words and give one example.`,`${ch.meaning} Example: ${ch.example}`];
    bank.think.push({prompt:sample[0],answer:'Sample: '+sample[1],lines:2,cost:2});
  }
  if(scope.some(c=>c.id===24)) bank.clock=shuffled([{"prompt": "Which country does this flag belong to?", "graphic": "<svg class=\"diagram\" viewBox=\"0 0 150 90\" role=\"img\" aria-label=\"White flag with a red circle in the centre\"><rect width=\"150\" height=\"90\" fill=\"white\"/><circle cx=\"75\" cy=\"45\" r=\"25\" fill=\"#bc002d\"/></svg>", "answer": "Japan"}, {"prompt": "Which country has this flag?", "graphic": "<svg class=\"diagram\" viewBox=\"0 0 150 90\" role=\"img\" aria-label=\"Flag with vertical blue, white and red bands\"><path d=\"M0 0h50v90H0z\" fill=\"#002654\"/><path d=\"M50 0h50v90H50z\" fill=\"white\"/><path d=\"M100 0h50v90h-50z\" fill=\"#ce1126\"/></svg>", "answer": "France"}]);
  return bank;
}
function makeResource(scope,amount,types,isPaper){
  const bank=pools(scope);
  let remaining=amount, qs=[], cursor=0;
  const cost=q=>isPaper?(q.cost??1):1;
  const used=new Set();
  while(remaining){
    let made=false;
    for(let j=0;j<types.length;j++){
      const idx=(cursor+j)%types.length,type=types[idx];
      const index=bank[type].findIndex(q=>cost(q)<=remaining&&!used.has(q.prompt));
      if(index<0) continue;
      const [q]=bank[type].splice(index,1);
      qs.push({...q,type});
      if(type!=='clock') used.add(q.prompt);
      remaining-=cost(q);
      cursor=(idx+1)%types.length;
      made=true;
      break;
    }
    if(!made) return null;
  }
  return {mode:isPaper?'paper':'worksheet',amount,qs,scope:scope.map(c=>c.id)};
}
function output(html,canShowKey,move=true){
  $('result').innerHTML=html;
  $('show-key').hidden=!canShowKey;
  $('output').hidden=false;
  if(move) $('result').focus();
}
function heading(title){return `<h2>${title}</h2><p>GK Spark · Grade 2</p>`;}
function showDocument(){
  const {mode:docMode,amount,qs}=last;
  const isPaper=docMode==='paper';
  const html=qs.map((q,i)=>{
    let rest=q.graphic??'';
    if(q.choices) rest+=`<span class="choices">${q.choices.map((a,k)=>`${String.fromCharCode(65+k)}. ${escapeHTML(a)}`).join(' &nbsp; · &nbsp; ')}</span>`;
    if(q.pairs) rest+=`<table class="matching"><thead><tr><th>Clues</th><th>Answers</th></tr></thead><tbody>${q.pairs.map(([f],k)=>`<tr><td>${k+1}. ${escapeHTML(f)}</td><td>${String.fromCharCode(65+k)}. ${escapeHTML(q.right[k])}</td></tr>`).join('')}</tbody></table>`;
    if(!q.choices&&q.type!=='fill') rest+=('<span class="answer-line"></span>').repeat(q.lines??1);
    return `<li>${isPaper?`<small class="score">[${q.cost??1} mark${q.cost===2?'s':''}]</small>`:''}<strong>${formats[q.type]}</strong><br>${escapeHTML(q.prompt)}${rest}</li>`;
  }).join('');
  output(`${heading(labels[docMode])}<p>${amount} ${isPaper?'marks':'questions'}</p><p>Name: _____________________ &nbsp; Date: __________</p><ol>${html}</ol>`,true);
}
function showKey(move=true){
  if(!last) return;
  output(`${heading('Answer key') }<p>For the most recent ${labels[last.mode].toLowerCase()}.</p><ol>${last.qs.map(q=>`<li>${escapeHTML(q.answer)}</li>`).join('')}</ol>`,false,move);
}
$('open-key').onclick=()=>showKey();
$('show-key').onclick=()=>setMode('key');
$('print').onclick=()=>window.print();
function showLesson(scope,minutes){
  const first=Math.floor(minutes*.15), middle=Math.floor(minutes*.45), practice=Math.floor(minutes*.25);
  const topics=scope.map(c=>`<section class="lesson-unit"><h3>${c.id}. ${escapeHTML(c.title)}</h3><p><b>Objectives</b> · Explain ${escapeHTML(c.word)} with an example and recall two facts from the chapter.</p><p><b>Warm-up (${first} min)</b> · Show ${c.visual} and invite pupils to connect it to the chapter title.</p><p><b>Teach (${middle} min)</b> · Read the chapter together. Explain ${escapeHTML(c.word.toLowerCase())} and model “${escapeHTML(c.example)}”</p><p><b>Pair activity (${practice} min)</b> · Give pairs these clues: ${c.facts.slice(0,2).map(([f])=>escapeHTML(f)+' ___').join(' / ')}. Ask each pair to explain one answer.</p><p><b>Exit check (${minutes-first-middle-practice} min)</b> · ${escapeHTML(think[c.id]?.[0]??'Write one fact you learned and illustrate the key word.')}</p></section>`).join('');
  output(heading('Lesson plan')+topics,false);
}
$('form').onsubmit=event=>{
  event.preventDefault();
  $('status').textContent='';
  const scope=selected();
  if(!scope.length){$('status').textContent='Select at least one chapter.';return;}
  if(mode==='lesson'){showLesson(scope,Number($('minutes').value));return;}
  const types=[...$('types').querySelectorAll(':checked')].map(x=>x.value);
  const amount=Number($('size').value);
  if(!types.length){$('status').textContent='Select at least one question type.';return;}
  const result=makeResource(scope,amount,types,mode==='paper');
  if(!result){$('status').textContent='This selection cannot make the requested total. Select more chapters or question types, or reduce the total. Flag diagrams requires Chapter 24.';return;}
  last=result;
  try{sessionStorage.setItem('gk-spark-grade-2-last',JSON.stringify(last));}catch{}
  showDocument();
};
function showWords(){
  const query=$('search').value.trim().toLowerCase(), id=$('dict-chapter').value;
  const words=chapters.filter(c=>(!id||String(c.id)===id)&&[c.word,c.meaning,c.title].some(v=>v.toLowerCase().includes(query)));
  $('dict-status').textContent=words.length?`${words.length} ${words.length===1?'entry':'entries'}`:'No matching words.';
  $('words').innerHTML=words.map(c=>`<article class="word">${imageChapters.has(c.id)?`<img class="word-image" src="visuals/${c.id}.png" alt="Book illustration for ${escapeHTML(c.word)}">`:`<span class="visual" aria-hidden="true">${c.visual}</span>`}<h3>${escapeHTML(c.word)}</h3><small>Chapter ${c.id} · ${escapeHTML(c.title)}</small><p>${escapeHTML(c.meaning)}</p><p><em>${escapeHTML(c.example)}</em></p><button type="button" data-word="${c.id}" aria-label="Hear ${escapeHTML(c.word)}">Hear pronunciation</button></article>`).join('');
}
$('search').oninput=showWords;
$('dict-chapter').onchange=showWords;
const audio = new Audio();
$('words').onclick=async e=>{
  const button=e.target.closest('[data-word]');
  if(!button)return;
  const word=chapters.find(c=>c.id===Number(button.dataset.word)).word;
  audio.src='audio/'+button.dataset.word+'.mp3';
  $('dict-status').textContent='Playing: '+word;
  try { await audio.play(); }
  catch(error){
    if(error.name!=='AbortError') $('dict-status').textContent='Audio could not play. Please try again.';
  }
};
audio.addEventListener('ended',showWords);
setMode('paper');
