const QUIZ_VISUALS = [{"chapter": 28, "prompt": "How many students play both games?", "answer": "5", "choices": ["8", "7", "20"], "graphic": "<svg class=\"quiz-diagram\" viewBox=\"0 0 250 125\" role=\"img\" aria-label=\"Venn diagram. Cricket only eight, overlap five, chess only seven.\"><circle cx=\"91\" cy=\"68\" r=\"48\" fill=\"#6bddc5\" fill-opacity=\".7\"/><circle cx=\"159\" cy=\"68\" r=\"48\" fill=\"#8294ef\" fill-opacity=\".7\"/><g fill=\"white\" font-size=\"15\" text-anchor=\"middle\"><text x=\"72\" y=\"16\">Cricket</text><text x=\"178\" y=\"16\">Chess</text><text x=\"75\" y=\"74\">8</text><text x=\"125\" y=\"74\">5</text><text x=\"176\" y=\"74\">7</text></g></svg>", "hint": "Look for the number in the shared region.", "explanation": "Five is in the overlap, so five students play both games."}, {"chapter": 34, "prompt": "Which direction do you travel from School to Park?", "answer": "East", "choices": ["North", "South", "West"], "graphic": "<svg class=\"quiz-diagram\" viewBox=\"0 0 250 125\" role=\"img\" aria-label=\"On a north-up map, School is on the left and Park is directly to its right.\"><path d=\"M52 67h146 M223 74V33m-7 8 7-8 7 8\" stroke=\"#65e4c4\" stroke-width=\"3\" fill=\"none\"/><circle cx=\"52\" cy=\"67\" r=\"6\" fill=\"#ffdf96\"/><circle cx=\"198\" cy=\"67\" r=\"6\" fill=\"#ffdf96\"/><g fill=\"white\" font-size=\"14\" text-anchor=\"middle\"><text x=\"52\" y=\"95\">School</text><text x=\"198\" y=\"95\">Park</text><text x=\"223\" y=\"25\">N</text></g></svg>", "hint": "With north at the top, east is to the right.", "explanation": "The park is directly to the right of the school. On this map that is east."}];
(() => {
const root = $('quiz');
const LETTERS = ['A','B','C','D'];
const points = [100,200,300,500,750,1000,1500,2000,3000,5000];
let round;
let pack = [];
let speechRequest = 0;

function stopSpeech(){
  speechRequest++;
  window.speechSynthesis?.cancel();
}

function speak(message){
  stopSpeech();
  const status=root.querySelector('[role="status"]');
  if(!window.speechSynthesis || !window.SpeechSynthesisUtterance){
    status.textContent='Read-aloud is unavailable in this browser.';
    return;
  }
  const request=speechRequest;
  const line=new SpeechSynthesisUtterance(message);
  line.lang='en-IN';
  line.rate=.85;
  line.onerror=({error})=>{
    if(request===speechRequest && error!=='interrupted' && error!=='canceled')
      status.textContent='Audio could not play. You can continue using the text.';
  };
  window.speechSynthesis.speak(line);
}

function optionsFor(answer, distractors){
  return shuffled([answer,...shuffled([...new Set(distractors)].filter(d=>d!==answer)).slice(0,3)]);
}

function makeQuestion(chapter, prompt, answer, choices, explanation, hint, difficulty, graphic=''){
  return {chapter:chapter.id,prompt,answer,choices:optionsFor(answer,choices),explanation,hint,difficulty,graphic};
}

function makePack(scope){
  const ids=new Set(scope.map(ch=>ch.id));
  const allAnswers=chapters.flatMap(ch=>ch.facts.map(([,answer])=>answer));
  const bank=scope.flatMap(ch=>{
    const similar=chapters.flatMap(other=>other.id!==ch.id ? other.facts.map(f=>f[1]) : []);
    const facts=ch.facts.flatMap(([cue,answer],i)=>{
      const alternative=similar.filter(value=>/^\d/.test(value)===/^\d/.test(answer));
      const related=ch.facts.map(([,a])=>a).filter(a=>a!==answer && /^\d/.test(a)===/^\d/.test(answer));
      const choices=related.concat(shuffled(alternative),allAnswers);
      const direct=makeQuestion(ch,cue.replace(/[.?!]+$/,'')+' …',answer,choices,
        cue+': '+answer+'.','The answer starts with '+answer.charAt(0).toUpperCase()+'.',i===0?1:2);
      const verify=makeQuestion(ch,'Which answer belongs with this clue? “'+cue+'”',answer,choices,
        'The matching answer is '+answer+'.','The answer starts with '+answer.charAt(0).toUpperCase()+'.',3);
      return [direct,verify];
    });
    const otherWords=chapters.filter(a=>a.id!==ch.id);
    return [...facts,
      makeQuestion(ch,'Which word means “'+ch.meaning+'”?',ch.word,otherWords.map(a=>a.word),ch.word+': '+ch.meaning,'Pick the word that fits the whole definition.',2),
      makeQuestion(ch,'What does “'+ch.word+'” mean?',ch.meaning,otherWords.map(a=>a.meaning),ch.example,'Recall how the word is used in this chapter.',1),
      makeQuestion(ch,'Which sentence shows the meaning of “'+ch.word+'”?',ch.example,otherWords.map(a=>a.example),ch.meaning,'Look for how the word or idea is used.',3),
      makeQuestion(ch,'Which chapter introduces this term? “'+ch.word+'”',ch.title,otherWords.map(a=>a.title),ch.meaning,'Use the meaning of the term to identify the topic.',2)
    ];
  });
  for(const item of QUIZ_VISUALS){
    if(!ids.has(item.chapter))continue;
    const chapter=chapters.find(ch=>ch.id===item.chapter);
    bank.push(makeQuestion(chapter,item.prompt,item.answer,item.choices,item.explanation,item.hint,3,item.graphic));
  }
  return bank.filter(q=>q.choices.length===4);
}

function chooseRound(chapter){
  const scope=chapter?chapters.filter(ch=>ch.id===chapter):chapters;
  const bank=makePack(scope);
  const selected=[];
  const remaining=shuffled(bank.filter(q=>!q.graphic));
  if(!chapter){
    const visual=shuffled(bank.filter(q=>q.graphic))[0];
    if(visual) selected.push(visual);
  }else{
    selected.push(...shuffled(bank.filter(q=>q.graphic)).slice(0,2));
  }
  while(selected.length<10 && remaining.length){
    const unused=remaining.findIndex(q=>!selected.some(p=>p.chapter===q.chapter));
    const i=unused<0?0:unused;
    selected.push(...remaining.splice(i,1));
  }
  return selected.sort((a,b)=>a.difficulty-b.difficulty);
}

function start(questions){
  stopSpeech();
  pack=questions;
  round={index:0,selected:-1,locked:false,removed:[],usedFifty:false,usedHint:false,hint:false,score:0,missed:[],correct:0};
  renderQuestion();
}

function layout(content){
  root.innerHTML='<div class="quiz-content">'+content+'</div><p class="quiz-status" role="status"></p>';
}

function setup(){
  stopSpeech();
  round=null;
  layout('<h2>GK Spark Quiz Challenge</h2><p>Answer up to ten questions and climb the points ladder. Use each lifeline once per round.</p><label for="quiz-scope">Choose a topic</label><select id="quiz-scope"><option value="">Mixed topics</option>'+chapters.map(ch=>'<option value="'+ch.id+'">'+ch.id+'. '+escapeHTML(ch.title)+'</option>').join('')+'</select><button class="primary quiz-start" data-quiz="start">Start quiz</button>');
}

function renderQuestion(){
  const q=pack[round.index];
  const correct=q.choices.indexOf(q.answer);
  const locked=round.locked;
  const options=q.choices.map((choice,i)=>{
    const removed=round.removed.includes(i);
    const state=locked?(i===correct?' correct':i===round.selected?' incorrect':''):'';
    return '<button class="quiz-option'+state+'" data-quiz="select" data-option="'+i+'" aria-pressed="'+(i===round.selected)+'" '+(locked||removed?'disabled':'')+'><b>'+LETTERS[i]+'</b><span>'+escapeHTML(removed?'Removed by 50:50':choice)+'</span></button>';
  }).join('');
  const ladder=points.slice(0,pack.length).map((p,i)=>'<li'+(i===round.index?' aria-current="step"':'')+'>'+p.toLocaleString('en-IN')+'</li>').reverse().join('');
  const feedback=locked?'<div class="quiz-feedback"><strong>'+(round.selected===correct?'Correct!':'Correct answer: '+escapeHTML(q.answer))+'</strong><p>'+escapeHTML(q.explanation)+'</p></div>':'';
  layout('<div class="quiz-board"><div><div class="quiz-top"><span>Question '+(round.index+1)+' of '+pack.length+'</span><span>'+round.score.toLocaleString('en-IN')+' points</span></div><h2 tabindex="-1">'+escapeHTML(q.prompt)+'</h2>'+q.graphic+'<div class="quiz-options">'+options+'</div><div class="quiz-actions"><button data-quiz="'+(locked?'hear-answer':'hear-question')+'">'+(locked?'Hear answer and explanation':'Hear question and options')+'</button><button data-quiz="stop-audio">Stop audio</button>'+(locked?'':'<button data-quiz="fifty" '+(round.usedFifty?'disabled':'')+'>50:50</button><button data-quiz="hint" '+(round.usedHint?'disabled':'')+'>Get a hint</button>')+'</div>'+(round.hint?'<p class="quiz-hint">'+escapeHTML(q.hint)+'</p>':'')+feedback+'<div class="quiz-actions"><button class="primary" data-quiz="'+(locked?'next':'lock')+'" '+(!locked&&round.selected<0?'disabled':'')+'>'+(locked?(round.index+1===pack.length?'See results':'Next question'):'Lock answer')+'</button><button data-quiz="reset">Start over</button></div></div><aside class="quiz-ladder"><h3>Points ladder</h3><ol reversed>'+ladder+'</ol></aside></div>');
}

function finish(){
  layout('<h2>Round complete</h2><p class="quiz-result">'+round.correct+' / '+pack.length+' correct</p><p>'+round.score.toLocaleString('en-IN')+' points earned</p>'+(round.missed.length?'<details><summary>Review missed questions</summary><ol>'+round.missed.map(q=>'<li><b>'+escapeHTML(q.prompt)+'</b><p>'+escapeHTML(q.answer)+' — '+escapeHTML(q.explanation)+'</p></li>').join('')+'</ol></details>':'')+'<div class="quiz-actions">'+(round.missed.length?'<button class="primary" data-quiz="retry">Retry missed questions</button>':'')+'<button data-quiz="reset">New round</button></div>');
}

root.addEventListener('click',event=>{
  const button=event.target.closest('[data-quiz]');
  if(!button || button.disabled)return;
  const action=button.dataset.quiz;
  if(action==='start'){start(chooseRound(Number($('quiz-scope').value)));return;}
  if(action==='reset'){setup();return;}
  if(action==='retry'){start(round.missed);return;}
  if(!round)return;
  const q=pack[round.index];
  const correct=q.choices.indexOf(q.answer);
  if(action==='hear-question'){
    const visual=q.graphic.match(/aria-label="([^"]+)"/)?.[1]??'';
    speak(q.prompt+' '+visual+' '+q.choices.map((value,i)=>round.removed.includes(i)?'':LETTERS[i]+'. '+value+'.').join(' '));
    return;
  }
  if(action==='hear-answer'){speak('The correct answer is '+q.answer+'. '+q.explanation);return;}
  if(action==='stop-audio'){stopSpeech();return;}
  if(action==='next' && round.locked){
    stopSpeech();
    if(round.index+1===pack.length){finish();return;}
    Object.assign(round,{index:round.index+1,selected:-1,locked:false,removed:[],hint:false});
  }else if(action==='select' && !round.locked){
    round.selected=Number(button.dataset.option);
  }else if(action==='lock' && !round.locked && round.selected>=0){
    stopSpeech();
    round.locked=true;
    if(round.selected===correct){ round.correct++;round.score+=points[round.index]; }
    else round.missed.push(q);
  }else if(action==='fifty' && !round.usedFifty && !round.locked){
    round.removed=shuffled([0,1,2,3].filter(i=>i!==correct)).slice(0,2);
    if(round.removed.includes(round.selected))round.selected=-1;
    round.usedFifty=true;
  }else if(action==='hint' && !round.usedHint && !round.locked){
    round.usedHint=true;
    round.hint=true;
  }
  renderQuestion();
  root.querySelector('h2')?.focus();
});

document.querySelectorAll('[data-student-tool]').forEach(button=>button.onclick=()=>{
  stopSpeech();
  audio.pause();
  const quiz=button.dataset.studentTool==='quiz';
  document.querySelectorAll('[data-student-tool]').forEach(b=>{
    const active=b===button;
    b.setAttribute('aria-pressed',String(active));
    b.classList.toggle('active',active);
  });
  $('dictionary').hidden=quiz;
  root.hidden=!quiz;
  if(quiz && !root.innerHTML)setup();
  if(!quiz)showWords();
});
$('student-back').addEventListener('click',stopSpeech);
for(const id of ['student','teacher-dictionary']) $(id).addEventListener('click',()=>{
  document.querySelector('[data-student-tool="dictionary"]').click();
});
window.addEventListener('pagehide',stopSpeech);
})();
