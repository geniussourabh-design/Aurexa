const $ = id => document.getElementById(id);
const imageChapters=new Set();
const labels = {paper:'Question paper', worksheet:'Worksheet', key:'Answer key', lesson:'Lesson plan', textbook:'Textbook answer keys', dictionary:'Audio-visual dictionary'};
const formats = {fill:'Fill in the blanks', mcq:'Multiple choice', tf:'True or false', match:'Matching', think:'Think Smart', clock:'Diagram reasoning'};
const escapeHTML = v => String(v).replace(/[&<>"']/g, x => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[x]));
const shuffled = items => {
  const copy=[...items];
  for(let i=copy.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[copy[i],copy[j]]=[copy[j],copy[i]];}
  return copy;
};
const selected = () => chapters.filter(c=>$('chapter-'+c.id).checked);
let mode='paper', last=null;
try { last=JSON.parse(sessionStorage.getItem('gk-spark-grade-6-last')); } catch {}
$('chapters').innerHTML=chapters.map(c=>`<label class="chapter"><input type="checkbox" id="chapter-${c.id}" checked><span class="ch-num">${c.id}</span>${escapeHTML(c.title)}</label>`).join('');
$('dict-chapter').insertAdjacentHTML('beforeend',chapters.map(c=>`<option value="${c.id}">${c.id}. ${escapeHTML(c.title)}</option>`).join(''));
function setScope(){
  const count=selected().length;
  $('scope').textContent=count===chapters.length?`All ${chapters.length} chapters`:`${count} selected chapter${count===1?'':'s'}`;
}
$('chapters').addEventListener('change',setScope);
for(const key of ['all','none']) $(key).onclick=()=>{
  chapters.forEach(c=>$('chapter-'+c.id).checked=key==='all');
  setScope();
};
function setMode(next){
  mode=next;
  document.querySelectorAll('[data-mode]').forEach(b=>{
    const selected=b.dataset.mode===next;
    b.setAttribute('aria-pressed',String(selected));
    b.classList.toggle('active',selected);
  });
  $('settings').hidden=(next==='lesson'||next==='textbook');
  $('size-field').hidden=(next==='lesson'||next==='textbook');
  $('size').disabled=(next==='lesson'||next==='textbook');
  $('lesson-field').hidden=$('minutes').disabled=next==='textbook';
  $('size-field').firstChild.nodeValue=next==='worksheet'?'Number of questions':'Maximum marks';
  $('paper-title').placeholder=labels[next];
  $('tool-title').textContent=next==='textbook'?'Textbook answer keys':next==='lesson'?'Lesson plan':'Question mix';
  $('generate').textContent=next==='textbook'?'Show selected answer keys':'Generate '+labels[next].toLowerCase();
  $('preview-title').textContent=next==='textbook'?'Textbook answer key preview':next==='lesson'?'Your lesson plan preview':'Your paper preview';
  $('status').textContent='';
  $('output').hidden=true;
  $('empty').hidden=false;
  $('show-key').disabled=true;
  $('student-tab').disabled=true;
  $('print').disabled=$('word').disabled=true;
  $('download-file').hidden=true;
  $('export-status').textContent='';
  $('shuffle').disabled=true;
}
function chooseRole(next){
  window.AurexaReadAloud.stop();
  $('home').hidden=next!=='home';
  $('teacher-view').hidden=next!=='teacher';
  $('learner').hidden=next!=='student';
  $('dictionary').hidden=next!=='student';
  if(next==='student') showWords();
}
$('teacher').onclick=()=>chooseRole('teacher');
$('student').onclick=$('teacher-dictionary').onclick=()=>chooseRole('student');
$('teacher-home').onclick=$('student-back').onclick=()=>chooseRole('home');
$('help').onclick=()=>$('help-dialog').showModal();
$('shuffle').onclick=()=>$('form').requestSubmit();
document.querySelectorAll('[data-mode]').forEach(b=>b.onclick=()=>setMode(b.dataset.mode));
const think = {"9": ["Why should people follow official disaster warnings?", "They help people understand the danger and choose safe actions."], "15": ["A stranger asks for your OTP. What should you do?", "Keep it private and tell a trusted adult."], "19": ["What would you do if a friend asked you to hide a mistake?", "Encourage them to tell the truth and offer to help put it right."], "28": ["What does an overlap show in a Venn diagram?", "The members shared by both sets."], "30": ["Why might a graph be easier to use than a list?", "It makes comparisons and trends easier to see."]};
function pools(scope){
  const facts=shuffled(scope.flatMap(c=>c.facts.map(([cue,answer])=>({cue,answer,c}))));
  const bank={fill:[],mcq:[],tf:[],match:[],think:[],clock:[]};
  const choiceGroups=[
    ['Asia','Africa','Europe','Australia'],['New Delhi','Mumbai','Bhopal','Jaipur','Chandigarh','Kavaratti','France','Egypt','Gujarat','Assam','Rajasthan','Faridabad','northern India','Morni Hills','Rakhigarhi','Konark'],
    ['Kalpana Chawla','Mahatma Gandhi','Sarojini Naidu','Lala Lajpat Rai','Rabindranath Tagore','Satyajit Ray','C. V. Raman','Vikram Sarabhai','Major Dhyan Chand','P. T. Usha','Netaji'],
    ['tabla','bansuri','sitar'],['boxing','hockey','chess'],['1947','1857','1906','1921'],['Diwali','Baisakhi','Pongal','Holi'],['source','course','mouth'],['plateau','mountain range','plain','coast'],['hour','week','year','minute'],['Tadasana','Vrikshasana','meditation'],['ballet','Bharatanatyam','Flamenco']
  ];
  for(const f of facts){
    const ofChapter=f.c.facts.map(p=>p[1]);
    const family=choiceGroups.find(group=>group.includes(f.answer));
    const options=shuffled([...new Set([...(family??ofChapter),...ofChapter])].filter(a=>a!==f.answer));
    bank.fill.push({prompt:f.cue+' ________',answer:f.answer});
    const choices=shuffled([f.answer,...options.slice(0,3)]);
    bank.mcq.push({prompt:f.cue+' …',choices,answer:`${String.fromCharCode(65+choices.indexOf(f.answer))}. ${f.answer}`});
    const wrong=options[0];
    const truth=Math.random()>.5;
    bank.tf.push({prompt:`${f.cue}: ${truth?f.answer:wrong}.`,answer:truth?'True':`False. Correct answer: ${f.answer}.`});
  }
  for(const ch of shuffled(scope)){
    const pairs=shuffled(ch.facts).slice(0,2);
    const right=shuffled(pairs.map(p=>p[1]));
    if(right[0]!==right[1]) bank.match.push({prompt:'Match the two clues to the correct answers.',pairs,right,answer:pairs.map(([_,a],i)=>`${i+1}–${String.fromCharCode(65+right.indexOf(a))} (${a})`).join(', '),cost:2});
    const sample=think[ch.id]??[`Explain “${ch.word}” in your own words and give one example.`,`${ch.meaning} Example: ${ch.example}`];
    bank.think.push({prompt:sample[0],answer:'Sample: '+sample[1],lines:2,cost:2});
  }
  if(scope.some(c=>c.id===28)) bank.clock=shuffled([{"prompt": "How many students play both games?", "graphic": "<svg class=\"diagram\" viewBox=\"0 0 260 125\" role=\"img\" aria-label=\"Venn diagram: Cricket only 8, overlap 5, Chess only 7\"><circle cx=\"94\" cy=\"66\" r=\"46\" fill=\"#dbeee2\" stroke=\"#0b5042\"/><circle cx=\"162\" cy=\"66\" r=\"46\" fill=\"#d8e6ff\" fill-opacity=\".8\" stroke=\"#164877\"/><g font-size=\"15\" text-anchor=\"middle\"><text x=\"65\" y=\"15\">Cricket</text><text x=\"192\" y=\"15\">Chess</text><text x=\"83\" y=\"72\">8</text><text x=\"128\" y=\"72\">5</text><text x=\"173\" y=\"72\">7</text></g></svg>", "answer": "5 students. The overlap contains those who play both."}, {"prompt": "How many students are shown in all?", "graphic": "<svg class=\"diagram\" viewBox=\"0 0 260 125\" role=\"img\" aria-label=\"Venn diagram: Cricket only 8, overlap 5, Chess only 7\"><circle cx=\"94\" cy=\"66\" r=\"46\" fill=\"#dbeee2\" stroke=\"#0b5042\"/><circle cx=\"162\" cy=\"66\" r=\"46\" fill=\"#d8e6ff\" fill-opacity=\".8\" stroke=\"#164877\"/><g font-size=\"15\" text-anchor=\"middle\"><text x=\"65\" y=\"15\">Cricket</text><text x=\"192\" y=\"15\">Chess</text><text x=\"83\" y=\"72\">8</text><text x=\"128\" y=\"72\">5</text><text x=\"173\" y=\"72\">7</text></g></svg>", "answer": "20 students. Add 8 + 5 + 7 and count the overlap once."}]);
  return bank;
}
function makeResource(scope,amount,types,isPaper){
  const bank=pools(scope);
  let remaining=amount, qs=[], cursor=0;
  const cost=q=>isPaper?(q.cost??1):1;
  const used=new Set();
  while(remaining){
    let made=false;
    for(let j=0;j<types.length;j++){
      const idx=(cursor+j)%types.length,type=types[idx];
      const index=bank[type].findIndex(q=>cost(q)<=remaining&&!used.has(q.prompt));
      if(index<0) continue;
      const [q]=bank[type].splice(index,1);
      qs.push({...q,type});
      if(type!=='clock') used.add(q.prompt);
      remaining-=cost(q);
      cursor=(idx+1)%types.length;
      made=true;
      break;
    }
    if(!made) return null;
  }
  return {mode:isPaper?'paper':'worksheet',amount,qs,scope:scope.map(c=>c.id)};
}
function output(html,canShowKey,move=true,view='document'){
  $('result').innerHTML=html;
  $('show-key').disabled=!(canShowKey||view==='key');
  $('student-tab').disabled=!(canShowKey||view==='key');
  $('show-key').classList.toggle('active',view==='key');
  $('student-tab').classList.toggle('active',view!=='key');
  $('output').hidden=false;
  $('empty').hidden=true;
  $('print').disabled=$('word').disabled=false;
  $('download-file').hidden=true;
  $('export-status').textContent='';
  $('shuffle').disabled=mode==='textbook';
  if(move) $('result').focus();
}
function schoolDetails(){
  return {school:$('school').value.trim(),title:$('paper-title').value.trim(),
    section:$('section').value.trim(),date:$('examdate').value,minutes:Number($('minutes').value)};
}
function heading(title,details={}){
  const items=[details.section?'Class / section: '+details.section:'',details.date?'Date: '+details.date:'',details.minutes?'Duration: '+details.minutes+' min':''].filter(Boolean);
  return `${details.school?`<div class="school-heading">${escapeHTML(details.school)}</div>`:''}<h2 class="exam-heading">${escapeHTML(title)}</h2><div class="paper-meta"><span>GK Spark · Grade 6</span>${items.map(item=>`<span>${escapeHTML(item)}</span>`).join('')}</div><div class="paper-rule"></div>`;
}
function showDocument(){
  const {mode:docMode,amount,qs}=last;
  const isPaper=docMode==='paper';
  const html=qs.map((q,i)=>{
    let rest=q.graphic??'';
    if(q.choices) rest+=`<span class="choices">${q.choices.map((a,k)=>`${String.fromCharCode(65+k)}. ${escapeHTML(a)}`).join(' &nbsp; · &nbsp; ')}</span>`;
    if(q.pairs) rest+=`<table class="matching"><thead><tr><th>Clues</th><th>Answers</th></tr></thead><tbody>${q.pairs.map(([f],k)=>`<tr><td>${k+1}. ${escapeHTML(f)}</td><td>${String.fromCharCode(65+k)}. ${escapeHTML(q.right[k])}</td></tr>`).join('')}</tbody></table>`;
    if(!q.choices&&q.type!=='fill') rest+=('<span class="answer-line"></span>').repeat(q.lines??1);
    return `<li>${isPaper?`<small class="score">[${q.cost??1} mark${q.cost===2?'s':''}]</small>`:''}<strong>${formats[q.type]}</strong><br>${escapeHTML(q.prompt)}${rest}</li>`;
  }).join('');
  output(`${heading(last.details?.title||labels[docMode],last.details)}<p>${amount} ${isPaper?'marks':'questions'}</p><p>Name: _____________________</p><ol>${html}</ol>`,true);
}
function showKey(move=true){
  if(!last) return;
  output(`${heading(last.details?.title ? last.details.title+' · Answer key' : 'Answer key',last.details) }<p>For the most recent ${labels[last.mode].toLowerCase()}.</p><ol>${last.qs.map(q=>`<li>${escapeHTML(q.answer)}</li>`).join('')}</ol>`,false,move,'key');
}
$('show-key').onclick=()=>showKey();
$('student-tab').onclick=()=>showDocument();

function showLesson(scope,minutes){
  const first=Math.floor(minutes*.15), middle=Math.floor(minutes*.45), practice=Math.floor(minutes*.25);
  const topics=scope.map(c=>`<section class="lesson-unit"><h3>${c.id}. ${escapeHTML(c.title)}</h3><p><b>Objectives</b> · Explain ${escapeHTML(c.word)} with an example and recall two facts from the chapter.</p><p><b>Warm-up (${first} min)</b> · Show ${c.visual} and invite pupils to connect it to the chapter title.</p><p><b>Teach (${middle} min)</b> · Read the chapter together. Explain ${escapeHTML(c.word.toLowerCase())} and model “${escapeHTML(c.example)}”</p><p><b>Pair activity (${practice} min)</b> · Give pairs these clues: ${c.facts.slice(0,2).map(([f])=>escapeHTML(f)+' ___').join(' / ')}. Ask each pair to explain one answer.</p><p><b>Exit check (${minutes-first-middle-practice} min)</b> · ${escapeHTML(think[c.id]?.[0]??'Write one fact you learned and illustrate the key word.')}</p></section>`).join('');
  output(heading('Lesson plan',schoolDetails())+topics,false);
}
function showTextbookKeys(scope){
  const details={...schoolDetails(),minutes:0};
  const sections=scope.map(ch=>`<section class="lesson-unit"><h3>${ch.id}. ${escapeHTML(ch.title)}</h3>${TEXTBOOK_KEYS[ch.id-1].map(answer=>`<p>${escapeHTML(answer)}</p>`).join('')}</section>`).join('');
  const selection=scope.length===chapters.length?'Complete book':scope.length===1?'One chapter':scope.length+' chapters';
  output(heading('Textbook answer keys',details)+`<p>${selection} · Accept other valid answers to open-ended questions.</p>`+sections,false);
}
$('form').onsubmit=event=>{
  event.preventDefault();
  $('status').textContent='';
  const scope=selected();
  if(!scope.length){$('status').textContent='Select at least one chapter.';return;}
  if(mode==='textbook'){showTextbookKeys(scope);return;}
  if(mode==='lesson'){showLesson(scope,Number($('minutes').value));return;}
  const types=[...$('types').querySelectorAll(':checked')].map(x=>x.value);
  const amount=Number($('size').value);
  if(!types.length){$('status').textContent='Select at least one question type.';return;}
  const result=makeResource(scope,amount,types,mode==='paper');
  if(!result){$('status').textContent='This selection cannot make the requested total. Select more chapters or question types, or reduce the total. Diagram reasoning requires Chapter 28.';return;}
  last={...result,details:schoolDetails()};
  try{sessionStorage.setItem('gk-spark-grade-6-last',JSON.stringify(last));}catch{}
  showDocument();
};
function showWords(){
  const query=$('search').value.trim().toLowerCase(), id=$('dict-chapter').value;
  const words=chapters.filter(c=>(!id||String(c.id)===id)&&[c.word,c.meaning,c.title].some(v=>v.toLowerCase().includes(query)));
  $('dict-status').textContent=words.length?`${words.length} ${words.length===1?'entry':'entries'}`:'No matching words.';
  $('words').innerHTML=words.map(c=>`<article class="word">${imageChapters.has(c.id)?`<img class="word-image" src="visuals/${c.id}.png" alt="Book illustration for ${escapeHTML(c.word)}">`:`<span class="visual" aria-hidden="true">${c.visual}</span>`}<h3>${escapeHTML(c.word)}</h3><small>Chapter ${c.id} · ${escapeHTML(c.title)}</small><p>${escapeHTML(c.meaning)}</p><p><em>${escapeHTML(c.example)}</em></p><button type="button" data-word="${c.id}" aria-label="Listen to ${escapeHTML(c.word)}: word, meaning and example">Listen</button></article>`).join('');
}
function refreshWords(){
  window.AurexaReadAloud.stop();
  showWords();
}
$('search').oninput=refreshWords;
$('dict-chapter').onchange=refreshWords;
$('words').onclick=e=>{
  const button=e.target.closest('[data-word]');
  if(!button)return;
  const entry=chapters.find(c=>c.id===Number(button.dataset.word));
  if(!entry)return;
  const sentence=value=>/[.!?]$/.test(value.trim())?value.trim():value.trim()+'.';
  const narration=sentence(entry.word)+' Meaning. '+sentence(entry.meaning)+' Example. '+sentence(entry.example);
  const status=$('dict-status');
  window.AurexaReadAloud.read(narration,'en-IN',message=>status.textContent=message.split(' / ')[0]);
};
setScope();
setMode('paper');
