(() => {
  const result = document.getElementById('result');
  const pdfButton = document.getElementById('print');
  const wordButton = document.getElementById('word');
  const link = document.getElementById('download-file');
  const status = document.getElementById('export-status');
  let currentUrl;
  let exporting = false;

  function snapshot() {
    const blocks = [];
    const structure = 'H2,H3,P,OL,UL,LI,SECTION,DIV,SVG,TABLE';
    function collect(node, prefix = '') {
      if (node.nodeType === 3) {
        const value = node.textContent.trim();
        if (value) blocks.push({text:prefix+value});
        return;
      }
      const tag = node.tagName.toUpperCase();
      if (tag === 'SVG') {
        const svg = node.cloneNode(true);
        svg.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
        blocks.push({svg});
      } else if (tag === 'TABLE') {
        [...node.rows].forEach(row => blocks.push({text:[...row.cells].map(cell=>cell.textContent.trim()).join('   |   ')}));
      } else if (tag === 'OL' || tag === 'UL') {
        [...node.children].forEach((child,i) => collect(child, tag==='OL' ? (i+1)+'. ' : '• '));
      } else if (tag === 'LI') {
        const clone=node.cloneNode(true);
        clone.querySelectorAll('svg,table,.answer-line').forEach(el=>el.remove());
        clone.querySelectorAll('br').forEach(el=>el.replaceWith(' '));
        clone.querySelectorAll('.choices').forEach(el=>el.prepend('  '));
        blocks.push({text:prefix+clone.textContent.trim(),keepWithNext:!!node.querySelector('svg,table')});
        node.querySelectorAll('svg,table,.answer-line').forEach(el=>{
          if(el.matches('.answer-line'))blocks.push({text:'____________________________________________'});
          else collect(el);
        });
      } else if (node.querySelector(structure)) {
        [...node.childNodes].forEach(child=>collect(child));
      } else {
        const content=node.matches('.paper-meta')?[...node.children].map(el=>el.textContent.trim()).join('   |   '):node.textContent.trim();
        if(content)blocks.push({text:content,heading:node.matches('h2,h3,.school-heading')});
      }
    }
    [...result.childNodes].forEach(node=>collect(node));
    return blocks;
  }

  async function diagram(svg) {
    const values = (svg.getAttribute('viewBox')||'0 0 250 125').trim().split(/[ ,]+/).map(Number);
    const width = 300;
    const height = Math.max(1,Math.round(width * (values[3]||125)/(values[2]||250)));
    svg.setAttribute('width',width);
    svg.setAttribute('height',height);
    const url = URL.createObjectURL(new Blob([new XMLSerializer().serializeToString(svg)],{type:'image/svg+xml'}));
    try {
      const img=new Image();
      img.src=url;
      await img.decode();
      const canvas=document.createElement('canvas');
      canvas.width=width*2;
      canvas.height=height*2;
      const ctx=canvas.getContext('2d');
      ctx.drawImage(img,0,0,canvas.width,canvas.height);
      const blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/png'));
      if(!blob)throw Error('A picture could not be exported.');
      return {bytes:await blob.arrayBuffer(),width,height};
    } finally {
      URL.revokeObjectURL(url);
    }
  }

  async function makePdf(blocks,title) {
    const {PDFDocument,StandardFonts}=window.PDFLib;
    const doc=await PDFDocument.create();
    doc.setTitle(title);
    const regular=await doc.embedFont(StandardFonts.Helvetica), bold=await doc.embedFont(StandardFonts.HelveticaBold);
    let page,y;
    function newPage(){page=doc.addPage([595.28,841.89]);y=792;}
    const safe=value=>value.replace(/→/g,' to ').replace(/[  ]/g,' ').replace(/[‑−]/g,'-').replace(/[^\x20-\x7E\xA0-\xFF“”‘’–—•…]/gu,char=>{
      try { regular.encodeText(char);return char; } catch { return ''; }
    });
    newPage();
    for(const block of blocks){
      if(block.image){
        const {bytes,width,height}=block.image;
        const ratio=Math.min(1,440/width,190/height);
        const span=height*ratio;
        if(y-span<48)newPage();
        page.drawImage(await doc.embedPng(bytes),{x:50,y:y-span,width:width*ratio,height:span});
        y-=span+10;
        continue;
      }
      const font=block.heading?bold:regular;
      const size=block.heading?13:10.5;
      const words=safe(block.text).split(/\s+/).filter(Boolean);
      const lines=[];
      let line='';
      for(const word of words){
        const next=line?line+' '+word:word;
        if(line&&font.widthOfTextAtSize(next,size)>495){lines.push(line);line=word;}
        else line=next;
      }
      if(line)lines.push(line);
      const step=size*1.4;
      if(y<50+(block.heading||block.keepWithNext?45:0))newPage();
      for(const text of lines){
        if(y<48)newPage();
        page.drawText(text,{x:50,y,size,font,maxWidth:495});
        y-=step;
      }
      y-=block.heading?8:5;
    }
    for(const [i,p] of doc.getPages().entries()){
      p.drawText(String(i+1),{x:288,y:23,size:9,font:regular});
    }
    return new Blob([await doc.save()],{type:'application/pdf'});
  }

  async function makeWord(blocks,title) {
    const {Document,Paragraph,TextRun,ImageRun,Packer,HeadingLevel}=window.docx;
    const children=blocks.map(block=>{
      if(block.image){
        const {bytes,width,height}=block.image;
        const scale=Math.min(1,380/width,220/height);
        return new Paragraph({children:[new ImageRun({type:'png',data:new Uint8Array(bytes),transformation:{width:Math.round(width*scale),height:Math.round(height*scale)}})]});
      }
      return new Paragraph({heading:block.heading?HeadingLevel.HEADING_2:undefined,keepNext:!!(block.heading||block.keepWithNext),spacing:{after:110},children:[new TextRun(block.text)]});
    });
    const doc=new Document({title,creator:'Aurexa Learning House',sections:[{children}]});
    return Packer.toBlob(doc);
  }

  async function download(kind){
    if(exporting||document.getElementById('output').hidden)return;
    exporting=true;
    link.hidden=true;
    pdfButton.disabled=wordButton.disabled=true;
    status.textContent='Preparing '+(kind==='pdf'?'PDF':'Word')+'…';
    try {
      const title=result.querySelector('h2')?.textContent?.trim()||'GK Spark';
      const blocks=snapshot();
      const ready=await Promise.all(blocks.map(async block=>block.svg?{image:await diagram(block.svg)}:block));
      const blob=kind==='pdf'?await makePdf(ready,title):await makeWord(ready,title);
      if(currentUrl)URL.revokeObjectURL(currentUrl);
      currentUrl=URL.createObjectURL(blob);
      const base=title.replace(/[^\p{L}\p{N}]+/gu,'-').replace(/^-|-$/g,'').slice(0,72)||'GK-Spark';
      link.href=currentUrl;
      link.download=base+'.'+kind;
      link.textContent='Save '+(kind==='pdf'?'PDF':'Word')+' file';
      link.hidden=false;
      status.textContent='File ready. Tap the save link if the download did not start.';
      link.click();
    } catch(error) {
      console.error(error);
      status.textContent='Could not create the file. Refresh the page and try again.';
    } finally {
      exporting=false;
      const hidden=document.getElementById('output').hidden;
      pdfButton.disabled=wordButton.disabled=hidden;
    }
  }
  pdfButton.addEventListener('click',()=>download('pdf'));
  wordButton.addEventListener('click',()=>download('docx'));
})();
