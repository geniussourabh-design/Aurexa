(() => {
  const result = document.getElementById('result');
  const pdfButton = document.getElementById('print');
  const wordButton = document.getElementById('word');
  const link = document.getElementById('download-file');
  const status = document.getElementById('export-status');
  let currentUrl;
  let exporting = false;

  function snapshot() {
    const blocks = [];
    const structure = 'H2,H3,P,OL,UL,LI,SECTION,DIV,SVG,TABLE';
    function collect(node, prefix = '') {
      if (node.nodeType === 3) {
        const value = node.textContent.trim();
        if (value) blocks.push({text:prefix+value});
        return;
      }
      const tag = node.tagName.toUpperCase();
      if (tag === 'SVG') {
        const svg = node.cloneNode(true);
        svg.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
        blocks.push({svg});
      } else if (tag === 'TABLE') {
        [...node.rows].forEach(row => blocks.push({text:[...row.cells].map(cell=>cell.textContent.trim()).join('   |   ')}));
      } else if (tag === 'OL' || tag === 'UL') {
        [...node.children].forEach((child,i) => collect(child, tag==='OL' ? (i+1)+'. ' : '• '));
      } else if (tag === 'LI') {
        const clone=node.cloneNode(true);
        clone.querySelectorAll('svg,table,.answer-line,.score,.choices').forEach(el=>el.remove());
        clone.querySelectorAll('br').forEach(el=>el.replaceWith(' '));
        blocks.push({text:prefix+clone.textContent.trim(),role:'question',score:node.querySelector('.score')?.textContent.trim(),
          keepWithNext:!!node.querySelector('svg,table,.choices,.answer-line')});
        const choices=node.querySelector('.choices');
        if(choices) choices.textContent.split(' · ').forEach(option=>blocks.push({text:option.trim(),role:'option'}));
        node.querySelectorAll('svg,table,.answer-line').forEach(el=>{
          if(el.matches('.answer-line'))blocks.push({text:'____________________________________________'});
          else collect(el);
        });
      } else if (node.querySelector(structure)) {
        [...node.childNodes].forEach(child=>collect(child));
      } else {
        const content=node.matches('.paper-meta')?[...node.children].map(el=>el.textContent.trim()).join('   |   '):node.textContent.trim();
        if(content)blocks.push({text:content,heading:node.matches('h2,h3,.school-heading'),
          role:node.matches('.school-heading')?'school':node.matches('.exam-heading')?'title':
            node.matches('.paper-meta')?'metadata':node.matches('p')&&/^\d+ marks$/.test(content)?'total':'',
          entries:node.matches('.paper-meta')?[...node.children].map(el=>el.textContent.trim()):undefined});
      }
    }
    [...result.childNodes].forEach(node=>collect(node));
    return blocks;
  }

  async function diagram(svg) {
    const values = (svg.getAttribute('viewBox')||'0 0 250 125').trim().split(/[ ,]+/).map(Number);
    const width = 300;
    const height = Math.max(1,Math.round(width * (values[3]||125)/(values[2]||250)));
    svg.setAttribute('width',width);
    svg.setAttribute('height',height);
    const url = URL.createObjectURL(new Blob([new XMLSerializer().serializeToString(svg)],{type:'image/svg+xml'}));
    try {
      const img=new Image();
      img.src=url;
      await img.decode();
      const canvas=document.createElement('canvas');
      canvas.width=width*2;
      canvas.height=height*2;
      const ctx=canvas.getContext('2d');
      ctx.drawImage(img,0,0,canvas.width,canvas.height);
      const blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/png'));
      if(!blob)throw Error('A picture could not be exported.');
      return {bytes:await blob.arrayBuffer(),width,height};
    } finally {
      URL.revokeObjectURL(url);
    }
  }

  async function makePdf(blocks,title) {
    const {PDFDocument,StandardFonts}=window.PDFLib;
    const doc=await PDFDocument.create();
    doc.setTitle(title);
    const regular=await doc.embedFont(StandardFonts.Helvetica), bold=await doc.embedFont(StandardFonts.HelveticaBold);
    let page,y;
    function newPage(){page=doc.addPage([595.28,841.89]);y=792;}
    const safe=value=>value.replace(/→/g,' to ').replace(/[  ]/g,' ').replace(/[‑−]/g,'-').replace(/[^\x20-\x7E\xA0-\xFF“”‘’–—•…]/gu,char=>{
      try { regular.encodeText(char);return char; } catch { return ''; }
    });
    newPage();
    const pageWidth=595.28, left=50, right=pageWidth-left;
    function wrap(text,font,size,width){
      const lines=[];
      let line='';
      for(const word of safe(text).split(/\s+/).filter(Boolean)){
        const next=line?line+' '+word:word;
        if(line&&font.widthOfTextAtSize(next,size)>width){lines.push(line);line=word;}
        else line=next;
      }
      if(line)lines.push(line);
      return lines;
    }
    for(let i=0;i<blocks.length;i++){
      const block=blocks[i];
      if(block.image){
        const {bytes,width,height}=block.image;
        const ratio=Math.min(1,440/width,190/height);
        const span=height*ratio;
        if(y-span<48)newPage();
        page.drawImage(await doc.embedPng(bytes),{x:left+18,y:y-span,width:width*ratio,height:span});
        y-=span+10;
        continue;
      }
      if(block.role==='metadata'){
        const entries=[...(block.entries??[block.text])];
        if(blocks[i+1]?.role==='total')entries.push('Maximum marks: '+blocks[++i].text.split(' ')[0]);
        const colWidth=(right-left)/2, size=10.5;
        for(let j=0;j<entries.length;j+=2){
          const columns=[0,1].map(k=>wrap(entries[j+k]??'',regular,size,colWidth-12));
          for(const [k,lines] of columns.entries()) for(const [row,text] of lines.entries()){
            const x=k===0?left:right-regular.widthOfTextAtSize(text,size);
            page.drawText(text,{x,y:y-14*row,size,font:regular});
          }
          y-=14*Math.max(1,...columns.map(lines=>lines.length));
        }
        page.drawLine({start:{x:left,y:y+1},end:{x:right,y:y+1},thickness:.65});
        y-=19;
        continue;
      }
      const centered=block.role==='school'||block.role==='title';
      const font=block.heading?bold:regular;
      const size=block.role==='school'?18:block.role==='title'?15:block.heading?13:11;
      const xBase=block.role==='option'?left+19:left;
      const score=block.score?safe(block.score):'';
      const scoreWidth=score?regular.widthOfTextAtSize(score,10)+14:0;
      const lines=wrap(block.text,font,size,right-xBase-scoreWidth);
      const step=size*1.4;
      if(y<50+(block.heading||block.keepWithNext?45:0))newPage();
      if(score)page.drawText(score,{x:right-regular.widthOfTextAtSize(score,10),y,size:10,font:regular});
      for(const text of lines){
        if(y<48)newPage();
        const x=centered?(pageWidth-font.widthOfTextAtSize(text,size))/2:xBase;
        page.drawText(text,{x,y,size,font});
        y-=step;
      }
      y-=centered?8:block.role==='option'?1:6;
    }
    for(const [i,p] of doc.getPages().entries()){
      p.drawText(String(i+1),{x:288,y:23,size:9,font:regular});
    }
    return new Blob([await doc.save()],{type:'application/pdf'});
  }

  async function makeWord(blocks,title) {
    const {Document,Paragraph,TextRun,ImageRun,Packer,AlignmentType,TabStopType,BorderStyle,Tab}=window.docx;
    const children=blocks.flatMap((block,i)=>{
      if(block.image){
        const {bytes,width,height}=block.image;
        const scale=Math.min(1,380/width,220/height);
        return new Paragraph({children:[new ImageRun({type:'png',data:new Uint8Array(bytes),transformation:{width:Math.round(width*scale),height:Math.round(height*scale)}})]});
      }
      if(block.role==='total'&&blocks[i-1]?.role==='metadata')return [];
      const rightTab={type:TabStopType.RIGHT,position:9906};
      if(block.role==='metadata'){
        const entries=[...(block.entries??[block.text])];
        if(blocks[i+1]?.role==='total')entries.push('Maximum marks: '+blocks[i+1].text.split(' ')[0]);
        return entries.filter((_,j)=>j%2===0).map((entry,j)=>{
          const right=entries[j*2+1];
          const bottom=j===Math.ceil(entries.length/2)-1;
          return new Paragraph({tabStops:[rightTab],spacing:{after:bottom?180:75},keepNext:true,
            border:bottom?{bottom:{style:BorderStyle.SINGLE,size:5,space:6,color:'222222'}}:undefined,
            children:[new TextRun({text:entry,size:21}),...(right?[new TextRun({children:[new Tab(),right],size:21})]:[])]});
        });
      }
      const centered=block.role==='school'||block.role==='title';
      const size=block.role==='school'?36:block.role==='title'?30:block.heading?26:22;
      return new Paragraph({alignment:centered?AlignmentType.CENTER:AlignmentType.LEFT,
        indent:block.role==='option'?{left:380}:undefined,tabStops:block.score?[rightTab]:undefined,
        keepNext:!!(block.heading||block.keepWithNext),spacing:{after:centered?160:block.role==='option'?30:110},
        children:[new TextRun({text:block.text,bold:!!block.heading,size}),...(block.score?[new TextRun({children:[new Tab(),block.score],size:20})]:[])]});
    });
    const doc=new Document({title,creator:'Aurexa Learning House',styles:{default:{document:{run:{font:'Arial',size:22}}}},
      sections:[{properties:{page:{size:{width:11906,height:16838},margin:{top:1000,bottom:1000,left:1000,right:1000}}},children}]});
    return Packer.toBlob(doc);
  }

  async function download(kind){
    if(exporting||document.getElementById('output').hidden)return;
    exporting=true;
    link.hidden=true;
    pdfButton.disabled=wordButton.disabled=true;
    status.textContent='Preparing '+(kind==='pdf'?'PDF':'Word')+'…';
    try {
      const title=result.querySelector('h2')?.textContent?.trim()||'GK Spark';
      const blocks=snapshot();
      const ready=await Promise.all(blocks.map(async block=>block.svg?{image:await diagram(block.svg)}:block));
      const blob=kind==='pdf'?await makePdf(ready,title):await makeWord(ready,title);
      if(currentUrl)URL.revokeObjectURL(currentUrl);
      currentUrl=URL.createObjectURL(blob);
      const base=title.replace(/[^\p{L}\p{N}]+/gu,'-').replace(/^-|-$/g,'').slice(0,72)||'GK-Spark';
      link.href=currentUrl;
      link.download=base+'.'+kind;
      link.textContent='Save '+(kind==='pdf'?'PDF':'Word')+' file';
      link.hidden=false;
      status.textContent='File ready. Tap the save link if the download did not start.';
      link.click();
    } catch(error) {
      console.error(error);
      status.textContent='Could not create the file. Refresh the page and try again.';
    } finally {
      exporting=false;
      const hidden=document.getElementById('output').hidden;
      pdfButton.disabled=wordButton.disabled=hidden;
    }
  }
  pdfButton.addEventListener('click',()=>download('pdf'));
  wordButton.addEventListener('click',()=>download('docx'));
})();
