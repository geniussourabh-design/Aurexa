/* Local, source-labelled learning lookup. No external service receives questions. */
(()=>{'use strict';
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const stop=new Set('क्या है हैं का की के को में से और एक यह वह किसे कहते कहता कौन how what is are the a an of in to explain please meaning means अर्थ बताओ बताइए समझाओ समझाइए होता होती होते do does i me my tell about give examples example उदाहरण many there and between difference अंतर कितने कितनी कितना kya hai hain hota hoti kise kahte batao samjhao matlab'.split(' '));
const map={noun:'संज्ञा',sangya:'संज्ञा',sangyaa:'संज्ञा',pronoun:'सर्वनाम',sarvanam:'सर्वनाम',sarvnaam:'सर्वनाम',adjective:'विशेषण',visheshan:'विशेषण',verb:'क्रिया',kriya:'क्रिया',vowel:'स्वर',vowels:'स्वर',swar:'स्वर',consonant:'व्यंजन',consonants:'व्यंजन',vyanjan:'व्यंजन',gender:'लिंग',ling:'लिंग',singular:'एकवचन',ekvachan:'एकवचन',plural:'बहुवचन',bahuvachan:'बहुवचन',language:'भाषा',bhasha:'भाषा',alphabet:'वर्णमाला',varnamala:'वर्णमाला',synonym:'पर्यायवाची',synonyms:'पर्यायवाची',paryayvachi:'पर्यायवाची',antonym:'विलोम',antonyms:'विलोम',opposite:'विलोम',vilom:'विलोम',matra:'मात्रा',matras:'मात्रा',sentence:'वाक्य',vakya:'वाक्य',word:'शब्द',shabd:'शब्द',tense:'काल',kaal:'काल',past:'भूतकाल',present:'वर्तमान',future:'भविष्य',idiom:'मुहावरा',idioms:'मुहावरा',muhavare:'मुहावरा',punctuation:'विराम',grammar:'व्याकरण',vyakaran:'व्याकरण',script:'लिपि',lipi:'लिपि',letter:'पत्र',story:'कहानी',kahani:'कहानी',poem:'कविता',kavita:'कविता',essay:'निबंध',nibandh:'निबंध',paragraph:'अनुच्छेद',dialogue:'संवाद',counting:'गिनती',ginti:'गिनती'};
function norm(s){return String(s).normalize('NFC').toLowerCase().replace(/[०-९]/g,c=>'०१२३४५६७८९'.indexOf(c)).replace(/[^\p{L}\p{M}\p{N}]+/gu,' ').trim()}
function tokens(s){return [...new Set(norm(s).split(/\s+/).filter(t=>t&&!stop.has(t)).map(t=>map[t]||t))]}
function engine(bank,notes,keys,words){
 const docs=[];const names=Object.fromEntries(bank.chapters.map(c=>[c.id,c.name]));
 for(const w of words)docs.push({...w,kind:'word',title:w.word,text:w.hi,search:`${w.word} ${w.aliases} ${w.hi} ${w.en} ${w.example}`});
 for(const ch of bank.chapters){const n=notes[ch.id];if(n)docs.push({kind:'summary',id:'summary-'+ch.id,chs:[ch.id],title:ch.name,text:n.hi,en:n.en,example:n.examples,search:`${ch.name} ${n.hi} ${n.en}`});}
 for(const q of bank.questions.filter(q=>!['medium','long'].includes(q.type)))docs.push({kind:'practice',id:q.id,chs:[q.ch],title:q.q,text:q.a,search:q.q,options:q.options,ref:q.ref,image:q.image,story:bank.story&&q.ch===15?bank.story:null,type:q.type});
 for(const ch of keys.chapters)for(const [i,s] of ch.sections.entries())docs.push({kind:'textbook',id:`key-${ch.id}-${i}`,chs:[ch.id],page:s.page,title:s.title,text:s.answers.map(a=>`${a.number}. ${a.answer}`).join('\n'),sample:s.sample,note:s.note,search:`${s.title} ${s.answers.map(a=>a.answer).join(' ')}`});
 for(const d of docs)d.ts=new Set(tokens(d.search));
 function search(query,ch=0){
  const raw=norm(query),qt=tokens(query);if(!qt.length)return [];
  const pageMatch=raw.match(/(?:page|पृष्ठ|पेज)\s*(\d+)/),numberMatch=raw.match(/(?:question|प्रश्न|q)\s*(\d+)/);
  if(pageMatch)return docs.filter(d=>d.kind==='textbook'&&d.page===+pageMatch[1]&&(!ch||d.chs.includes(+ch))&&(!numberMatch||new RegExp('(?:प्रश्न|question)\\s*'+numberMatch[1]+'(?:\\D|$)').test(d.title))).map(d=>({...d,score:10})).slice(0,8);
  const countIntent=/(कितने|कितनी|कितना|how many)/i.test(query);
  if(!countIntent&&qt.length===1){const definition=docs.find(d=>d.kind==='word'&&(!ch||d.chs.includes(+ch))&&norm(d.word)===qt[0]);if(definition)return [{...definition,score:10}];}
  if(/(?:difference|between|अंतर)/i.test(query)){
   const matches=docs.filter(d=>d.kind==='word'&&(!ch||d.chs.includes(+ch))&&qt.includes(norm(d.word)));
   if(matches.length>=2)return matches.slice(0,4).map(d=>({...d,score:10}));
  }
  return docs.filter(d=>!ch||d.chs.includes(+ch)).map(d=>{let hit=qt.filter(t=>d.ts.has(t)).length;let coverage=hit/qt.length;if(!hit||coverage<.55)return null;
    let score=coverage*4+hit*.12;
    if(norm(d.title)===raw)score+=5;
    if(d.kind==='word'){const aliases=norm(d.aliases).split(' ');const matched=qt.some(t=>norm(d.word)===t||aliases.includes(t));score+=matched?2.5:-1;if(countIntent)score-=3;}
    if(d.kind==='practice')score+=d.type==='short'?1.3:d.type==='tf'?.3:1.0;
    if(d.kind==='textbook')score-=.7;
    if(d.kind==='summary')score-=.3;
    return {...d,score};}).filter(Boolean).sort((a,b)=>b.score-a.score).filter((d,i,a)=>a.findIndex(x=>x.title===d.title&&x.text===d.text)===i).slice(0,5);
 }
 return {search,names,words,bank};
}
let resourcePromise,revision=0;
function resources(){if(!resourcePromise)resourcePromise=Promise.all(['bank.json','summaries.json','textbook-keys.json','vocabulary.json'].map(p=>fetch(p).then(r=>{if(!r.ok)throw Error('load');return r.json()}))).then(([b,n,k,w])=>engine(b,n,k,w)).catch(e=>{resourcePromise=null;throw e});return resourcePromise;}
function cancel(){window.AurexaVisualDictionary?.cancel();revision++;window.AurexaReadAloud?.stop()}
async function mount(container,ch,view){window.AurexaVisualDictionary?.cancel();const run=++revision;container.innerHTML='<p role="status">Loading learning help… / सीखने की सहायता खुल रही है…</p>';try{const r=await resources();if(run!==revision||!container.isConnected)return;
 const vocabulary=view==='vocabulary';
 container.innerHTML=`<article class="learning-card student-help"><p class="eyebrow">${vocabulary?'WORDS TO DISCOVER':'ASK FROM THE TEXTBOOK'}</p><h2>${vocabulary?'Audio-Visual Dictionary / देखो, सुनो और सीखो':'Ask from the Textbook / पुस्तक से पूछें'}</h2><p>${vocabulary?'Watch the animation and hear the Hindi word, its meaning, and an example. Playback lasts at least nine seconds and continues until narration finishes.':'Type a question in Hindi or English. Find matching explanations, practice answers and textbook exercise answers.'}</p><p lang="hi">${vocabulary?'Play दबाएँ: एनीमेशन के साथ शब्द, उसका अर्थ और फिर उदाहरण सुनें।':'जैसे: “संज्ञा क्या है?” या “पृष्ठ 44 प्रश्न 2”। नीचे मिले प्रश्न को अपने प्रश्न से मिलाएँ।'}</p><form id="helpForm"><label for="helpQuery">${vocabulary?'Find a word / शब्द खोजें':'Your question / आपका प्रश्न'}</label><div class="help-input-row"><input id="helpQuery" maxlength="250" autocomplete="off" placeholder="${vocabulary?'जैसे: मेघ, पवन, noun…':'जैसे: संज्ञा क्या है? / What is a noun?'}"><button class="primary" type="submit">${vocabulary?'Find meaning':'Find answers'} ↗</button></div><label for="helpScope">Search in / कहाँ खोजें</label><select id="helpScope"><option value="${ch}">Selected chapter: ${esc(r.names[ch])}</option><option value="0">Whole book / पूरी पुस्तक</option></select></form><p class="small muted">${vocabulary?'Meanings are teaching explanations linked to this grade’s chapters.':'This searches prepared book-based resources; it is not an open-ended AI chat. Textbook answers show printed page numbers; practice answers are labelled separately.'}</p><div class="help-suggestions" id="helpSuggestions"></div><p id="helpStatus" role="status" aria-live="polite"></p><div id="helpResults"></div></article>`;
 const $=id=>container.querySelector('#'+id),query=$('helpQuery'),scope=$('helpScope'),results=$('helpResults'),status=$('helpStatus');
 function source(d){const ids=+scope.value?d.chs.filter(id=>id===+scope.value):d.chs.slice(0,3);const chapters=ids.map(id=>`${id}. ${r.names[id]}`).join(' · ')+(!+scope.value&&d.chs.length>3?' · +'+(d.chs.length-3)+' chapters':'');return `${d.kind==='textbook'?'Textbook answer · पुस्तक पृष्ठ '+d.page:d.kind==='practice'?'Adapted practice answer':d.kind==='summary'?'Chapter summary':'Word explanation'} · ${chapters}`}
 function show(docs){results.innerHTML=docs.map((d,i)=>`<article class="help-answer"><p class="eyebrow">${esc(source(d))}</p><h3 lang="hi">${esc(d.title||d.word)}</h3>${vocabulary&&d.kind==='word'?window.AurexaVisualDictionary.markup(d,i):''}${d.options?`<p lang="hi">${d.options.map(esc).join(' / ')}</p>`:''}<p class="help-answer-text" lang="hi">${esc(d.text||d.hi)}</p>${d.en?`<p lang="en">${esc(d.en)}</p>`:''}${d.example?`<p lang="hi"><strong>उदाहरण:</strong> ${esc(d.example)}</p>`:''}${d.sample?'<p class="small muted">नमूना उत्तर · Other appropriate answers are accepted.</p>':''}${d.note?`<p class="small muted">${esc(d.note)}</p>`:''}${d.image?`<img class="learning-picture" src="${esc(d.image)}" alt="प्रश्न का चित्र">`:''}${d.story?`<aside class="passage" lang="hi">${esc(d.story)}</aside>`:''}${d.ref?reference(d.ref,r.bank):''}<button type="button" data-help-speak="${i}">🔊 Listen in Hindi</button>${d.en?`<button type="button" data-help-english="${i}">Listen in English</button>`:''}</article>`).join('');
 if(vocabulary)window.AurexaVisualDictionary.bind(results,docs);
 results.querySelectorAll('[data-help-speak]').forEach(b=>{b.disabled=!window.AurexaReadAloud?.supported;b.onclick=()=>window.AurexaReadAloud.read((docs[+b.dataset.helpSpeak].text||docs[+b.dataset.helpSpeak].hi)+' '+(docs[+b.dataset.helpSpeak].example||''),'hi-IN',message=>status.textContent=message)});
 results.querySelectorAll('[data-help-english]').forEach(b=>{b.disabled=!window.AurexaReadAloud?.supported;b.onclick=()=>window.AurexaReadAloud.read(docs[+b.dataset.helpEnglish].en,'en-IN',message=>status.textContent=message)});
 }
 function reference(id,b){const ref=b.references?.find(x=>x.id===id);return ref?`<aside class="passage"><strong>${esc(ref.title)}</strong><p lang="hi">${esc(ref.text)}</p>${ref.image?`<img class="learning-picture" src="${esc(ref.image)}" alt="${esc(ref.title)}">`:''}</aside>`:''}
 function find(){window.AurexaVisualDictionary?.cancel();window.AurexaReadAloud?.stop();const q=query.value.trim();if(q.length<2&&q.length){status.textContent='Please enter a word or a short question / शब्द या छोटा प्रश्न लिखें।';results.innerHTML='';return}if(!q&&!vocabulary){status.textContent='Type a question or choose an example below.';results.innerHTML='';return}
 let docs;if(vocabulary){const qt=tokens(q);docs=r.words.filter(w=>(!+scope.value||w.chs.includes(+scope.value))&&(!q||norm(w.word+' '+w.aliases).includes(norm(q))||qt.some(t=>tokens(w.word+' '+w.aliases).includes(t)))).map(w=>({...w,kind:'word',title:w.word,text:w.hi}));}else docs=r.search(q,+scope.value);
 status.textContent=docs.length?`${docs.length} ${vocabulary?'word(s)':'matching resource(s)'} found. ${vocabulary?'':'Read the question or heading before using its answer.'}`:'No close match in this scope. Try a shorter question, a Hindi keyword, or Whole book. Ask your teacher if you still need help. / सही मिलान नहीं मिला। छोटा प्रश्न या पूरी पुस्तक चुनें।';show(docs);
 }
 $('helpForm').onsubmit=e=>{e.preventDefault();find()};scope.onchange=find;if(vocabulary)query.oninput=find;
 const suggestions=vocabulary?r.words.filter(w=>w.chs.includes(ch)).slice(0,5).map(w=>w.word):[r.names[ch]+' क्या है?',...r.bank.questions.filter(q=>q.ch===ch&&q.type==='short').slice(0,2).map(q=>q.q)];
 $('helpSuggestions').innerHTML=suggestions.map((s,i)=>`<button type="button" data-help-example="${i}">${esc(s)}</button>`).join('');$('helpSuggestions').querySelectorAll('button').forEach(b=>b.onclick=()=>{query.value=suggestions[+b.dataset.helpExample];find()});if(vocabulary)find();
 }catch{if(run===revision)container.innerHTML='<article class="learning-card"><h2>Learning help could not load</h2><p>Please choose another tab and try again.</p></article>'}}
window.AurexaStudentHelp={mount,cancel,engine,tokens,norm};
})();
