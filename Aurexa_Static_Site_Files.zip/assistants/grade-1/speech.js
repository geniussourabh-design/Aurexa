/* Browser voices may arrive after page load. An empty list is not proof that speech is unavailable. */
(()=>{'use strict';
const supported='speechSynthesis' in window&&'SpeechSynthesisUtterance' in window;
const synth=supported?window.speechSynthesis:null;
let active=null,revision=0,timer=null;
function clearTimer(){if(timer!==null){clearTimeout(timer);timer=null}}
function stop(){revision++;clearTimer();active=null;if(synth)synth.cancel()}
function read(text,lang,report){stop();if(!supported){report('Read-aloud is not supported in this browser. Try opening this page in your phone’s main browser.');return}
 const run=revision,u=new window.SpeechSynthesisUtterance(text);active=u;u.lang=lang;u.rate=.85;
 // Keep the click gesture: do not await voiceschanged before calling speak.
 const prefix=lang.split('-')[0].toLowerCase(),voices=synth.getVoices();
 const voice=voices.find(v=>v.lang.toLowerCase()===lang.toLowerCase())||voices.find(v=>v.lang.toLowerCase().split(/[-_]/)[0]===prefix);
 if(voice)u.voice=voice; // Otherwise ask the browser to resolve u.lang itself.
 const isCurrent=()=>run===revision&&active===u;
 u.onstart=()=>{if(isCurrent()){clearTimer();report('Reading… / पढ़ा जा रहा है…')}};
 u.onend=()=>{if(isCurrent()){clearTimer();active=null;report('Finished. / पूरा हुआ।')}};
 u.onerror=e=>{if(!isCurrent())return;clearTimer();active=null;if(e.error==='canceled'||e.error==='interrupted')return;
 report(e.error==='language-unavailable'||e.error==='voice-unavailable'?'Your browser could not provide this language. Enable a Hindi or English voice in your device’s text-to-speech settings, then try again.':e.error==='not-allowed'?'Audio was blocked. Open this link in your main browser and tap Listen again.':'Audio could not start. Check media volume and your device’s text-to-speech settings, then tap Listen again.');};
 report('Starting audio… / ऑडियो शुरू हो रहा है…');
 timer=setTimeout(()=>{if(isCurrent()){stop();report('Audio did not start. Open this link in your main browser, check media volume and text-to-speech settings, then try again.')}},15000);
 try{synth.resume();synth.speak(u)}catch{if(isCurrent()){stop();report('Audio could not start in this browser. Please try your phone’s main browser.')}}
}
function pause(report){if(!synth||!active)return;if(synth.paused){synth.resume();report('Reading… / पढ़ा जा रहा है…')}else{synth.pause();clearTimer();report('Paused. Tap Pause / Resume to continue.')}}
if(synth)synth.getVoices();
window.AurexaReadAloud={supported,read,stop,pause};
})();
