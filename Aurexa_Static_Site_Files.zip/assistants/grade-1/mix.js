/* Exact quotas use a chapter-to-slot matching so every selected chapter is covered. */
function typeMarks(t){return ({mcq:1,tf:1,fill:1,short:2,medium:4,long:6})[t]}
function updateMix(){const exact=document.getElementById('exactCounts').checked;let count=0,marks=0;for(const t of Object.keys(types)){const n=document.getElementById('count-'+t);if(!n)continue;const selected=selectedTypes().includes(t);n.disabled=!exact||!selected;if(exact&&selected){count+=Number(n.value);marks+=Number(n.value)*typeMarks(t)}}document.getElementById('marks').readOnly=exact;if(exact)document.getElementById('marks').value=marks;document.getElementById('mixTotal').textContent=exact?`${count} numbered questions · ${marks} marks. Every selected chapter must fit.`:'Automatic mix: enter maximum marks; or enable exact counts.'}
function initMix(){document.getElementById('exactCounts').onchange=updateMix;document.querySelectorAll('.type-option input').forEach(n=>n.addEventListener('change',updateMix));updateMix()}
function buildQuestionMix(pool,chs,ts,max){
 const exact=document.getElementById('exactCounts').checked,quota={};
 if(exact)for(const t of ts){const n=Number(document.getElementById('count-'+t).value);if(!Number.isInteger(n)||n<0||n>100)throw Error('Question counts must be whole numbers from 0 to 100.');quota[t]=n;if(n>pool.filter(q=>q.type===t).length)throw Error(`Not enough ${types[t].label} in these chapters. Reduce the count or add chapters.`)}
 const desired=ts.filter(t=>!exact||quota[t]>0);
 if(exact&&Object.values(quota).reduce((s,n)=>s+n,0)<chs.length)throw Error('Use at least one question per selected chapter, or select fewer chapters.');
 for(let attempt=0;attempt<250;attempt++){
  const result=[],used=new Set(),counts={};let total=0;
  const compatible=q=>!(q.sourceIds||[q.id]).some(id=>used.has(id));
  function take(q){result.push(structuredClone(q));(q.sourceIds||[q.id]).forEach(id=>used.add(id));counts[q.type]=(counts[q.type]||0)+1;total+=q.marks}
  if(exact){
   const order=shuffle(desired).sort((a,b)=>typeMarks(b)-typeMarks(a));
   for(const t of order){for(let n=0;n<quota[t];n++){let candidates=shuffle(pool.filter(q=>q.type===t&&compatible(q)));candidates.sort((a,b)=>result.filter(q=>q.ch===a.ch).length-result.filter(q=>q.ch===b.ch).length);if(!candidates.length)break;take(candidates[0])}}
  }else{
   // Prefer covering missing chapters/types, then balance remaining chapter counts.
   while(total<max){const missingCh=chs.filter(ch=>!result.some(q=>q.ch===ch)),missingType=ts.filter(t=>!result.some(q=>q.type===t));let candidates=shuffle(pool.filter(q=>compatible(q)&&q.marks<=max-total));
    candidates.sort((a,b)=>{const score=q=>(missingCh.includes(q.ch)?1000:0)+(missingType.includes(q.type)?500:0)-result.filter(x=>x.ch===q.ch).length*10;return score(b)-score(a)});
    if(!candidates.length)break;take(candidates[0]);
   }
  }
  if(total===max&&chs.every(ch=>result.some(q=>q.ch===ch))&&desired.every(t=>result.some(q=>q.type===t))&&(!exact||desired.every(t=>counts[t]===quota[t])))return result;
 }
 throw Error('This mix cannot fit every chapter without repeating questions or their parts. Increase marks, reduce counts, or add chapters. Automatic mode needs at least one question per selected type and chapter.');
}
