/* Exact quotas use a chapter-to-slot matching so every selected chapter is covered. */
function typeMarks(t){return ({mcq:1,tf:1,fill:1,short:2,medium:4,long:6})[t]}
function updateMix(){const exact=document.getElementById('exactCounts').checked;let count=0,marks=0;for(const t of Object.keys(types)){const n=document.getElementById('count-'+t);if(!n)continue;const selected=selectedTypes().includes(t);n.disabled=!exact||!selected;if(exact&&selected){count+=Number(n.value);marks+=Number(n.value)*typeMarks(t)}}document.getElementById('marks').readOnly=exact;if(exact)document.getElementById('marks').value=marks;document.getElementById('mixTotal').textContent=exact?`${count} numbered questions · ${marks} marks. Every selected chapter must fit.`:'Automatic mix: enter maximum marks; or enable exact counts.'}
function invalidatePaper(message){
 if(!paper&&!message)return;
 paper=null;document.getElementById('summary').textContent='';
 document.getElementById('preview').innerHTML='<div class="empty"><h3>'+ (message?'Paper was not generated':'Settings changed')+'</h3><p>'+esc(message||'Click Generate paper to build a paper using the current chapters and marks.')+'</p></div>';
 for(const id of ['pdf','word','shuffle'])document.getElementById(id).disabled=true;
 if(!document.getElementById('exactCounts').checked)for(const t of Object.keys(types))document.getElementById('count-'+t).value=0;
}
function showGeneratedCounts(p){
 if(document.getElementById('exactCounts').checked)return;
 for(const t of Object.keys(types))document.getElementById('count-'+t).value=p.questions.filter(q=>q.type===t).length;
 document.getElementById('mixTotal').textContent=p.questions.length+' questions · '+p.questions.reduce((n,q)=>n+q.marks,0)+' marks · generated paper';
}
function initMix(){
 document.getElementById('exactCounts').onchange=()=>{invalidatePaper();updateMix()};
 document.querySelectorAll('.type-count').forEach(n=>n.addEventListener('input',()=>{invalidatePaper();updateMix()}));
 document.querySelectorAll('.type-option input[type=checkbox]').forEach(n=>n.addEventListener('change',()=>{invalidatePaper();updateMix()}));
 document.getElementById('marks').addEventListener('input',()=>{invalidatePaper();updateMix()});
 if(!document.getElementById('exactCounts').checked)for(const t of Object.keys(types))document.getElementById('count-'+t).value=0;
 updateMix();
}

function buildQuestionMix(pool,chs,ts,max){
 const exact=document.getElementById('exactCounts').checked,quota={};
 if(exact)for(const t of ts){const n=Number(document.getElementById('count-'+t).value);if(!Number.isInteger(n)||n<0||n>100)throw Error('Question counts must be whole numbers from 0 to 100.');quota[t]=n;if(n>pool.filter(q=>q.type===t).length)throw Error(`Not enough ${types[t].label} in these chapters. Reduce the count or add chapters.`)}
 if(!exact&&max%2&&!ts.some(t=>typeMarks(t)===1))throw Error('A '+max+'-mark paper needs a 1-mark question. Select Multiple choice, True / false or Fill in the blanks; short, medium and long questions all have even marks.');
 const desired=ts.filter(t=>!exact||quota[t]>0);
 if(exact&&Object.values(quota).reduce((s,n)=>s+n,0)<chs.length)throw Error('Use at least one question per selected chapter, or select fewer chapters.');
 for(let attempt=0;attempt<250;attempt++){
  const result=[],used=new Set(),counts={};let total=0;
  const compatible=q=>!(q.sourceIds||[q.id]).some(id=>used.has(id));
  function take(q){result.push(structuredClone(q));(q.sourceIds||[q.id]).forEach(id=>used.add(id));counts[q.type]=(counts[q.type]||0)+1;total+=q.marks}
  if(exact){
   const order=shuffle(desired).sort((a,b)=>typeMarks(b)-typeMarks(a));
   for(const t of order){for(let n=0;n<quota[t];n++){let candidates=shuffle(pool.filter(q=>q.type===t&&compatible(q)));candidates.sort((a,b)=>result.filter(q=>q.ch===a.ch).length-result.filter(q=>q.ch===b.ch).length);if(!candidates.length)break;take(candidates[0])}}
  }else{
   // Reserve each requested type first, then cover chapters at their lowest cost.
   for(const t of [...ts].sort((a,b)=>typeMarks(b)-typeMarks(a))){
    let candidates=shuffle(pool.filter(q=>q.type===t&&compatible(q)&&q.marks<=max-total));
    candidates.sort((a,b)=>Number(result.some(q=>q.ch===a.ch))-Number(result.some(q=>q.ch===b.ch)));
    if(candidates.length)take(candidates[0]);
   }
   for(const ch of shuffle(chs.filter(ch=>!result.some(q=>q.ch===ch)))){
    const candidates=shuffle(pool.filter(q=>q.ch===ch&&compatible(q)&&q.marks<=max-total));
    candidates.sort((a,b)=>a.marks-b.marks);
    if(candidates.length)take(candidates[0]);
   }
   while(total<max){
    const candidates=shuffle(pool.filter(q=>compatible(q)&&q.marks<=max-total));
    candidates.sort((a,b)=>a.marks-b.marks||result.filter(q=>q.ch===a.ch).length-result.filter(q=>q.ch===b.ch).length);
    if(!candidates.length)break;take(candidates[0]);
   }
  }
  if(total===max&&chs.every(ch=>result.some(q=>q.ch===ch))&&desired.every(t=>result.some(q=>q.type===t))&&(!exact||desired.every(t=>counts[t]===quota[t])))return result;
 }
 throw Error('This mix cannot fit every chapter without repeating questions or their parts. Increase marks, reduce counts, or add chapters. Automatic mode needs at least one question per selected type and chapter.');
}
